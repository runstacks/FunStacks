import 'package:dio/dio.dart';
import 'package:get/get.dart' hide Response;
import '../models/models.dart';
import '../providers/auth_provider.dart';

class ApiService extends GetxService {
  static const String baseUrl = 'https://www.moltbook.com/api/v1';

  late final Dio _dio;

  @override
  void onInit() {
    super.onInit();
    _dio = Dio(BaseOptions(
      baseUrl: baseUrl,
      connectTimeout: const Duration(seconds: 20),
      receiveTimeout: const Duration(seconds: 30),
      headers: {
        'Content-Type': 'application/json',
        'Accept': 'application/json',
      },
    ));

    _dio.interceptors.add(InterceptorsWrapper(
      onRequest: (options, handler) {
        final authProvider = Get.find<AuthProvider>();
        final key = authProvider.apiKey.value;
        if (key.isNotEmpty) {
          options.headers['Authorization'] = 'Bearer $key';
        }
        return handler.next(options);
      },
      onError: (error, handler) {
        if (error.response?.statusCode == 401) {
          Get.find<AuthProvider>().logout();
        }
        return handler.next(error);
      },
    ));
  }

  // ==================== AGENTS ====================

  Future<Agent> validateKey(String apiKey) async {
    try {
      final response = await _dio.get(
        '/agents/me',
        options: Options(headers: {'Authorization': 'Bearer $apiKey'}),
      );
      return Agent.fromJson(response.data is Map<String, dynamic>
          ? response.data as Map<String, dynamic>
          : {});
    } on DioException catch (e) {
      throw _mapDioError(e);
    }
  }

  Future<Agent> getMyProfile() async {
    try {
      final response = await _dio.get('/agents/me');
      return Agent.fromJson(response.data is Map<String, dynamic>
          ? response.data as Map<String, dynamic>
          : {});
    } on DioException catch (e) {
      throw _mapDioError(e);
    }
  }

  // ==================== FEED / POSTS ====================

  /// Get posts sorted by newest first
  Future<PaginatedResponse<Post>> getPostsNew({int limit = 30, String? cursor}) async {
    try {
      final params = <String, dynamic>{'sort': 'new', 'limit': limit};
      if (cursor != null) params['cursor'] = cursor;
      final response = await _dio.get('/posts', queryParameters: params);
      return _parsePosts(response.data);
    } on DioException catch (e) {
      throw _mapDioError(e);
    }
  }

  /// Get posts sorted by top score
  Future<PaginatedResponse<Post>> getPostsTop({int limit = 30, String? cursor}) async {
    try {
      final params = <String, dynamic>{'sort': 'top', 'limit': limit};
      if (cursor != null) params['cursor'] = cursor;
      final response = await _dio.get('/posts', queryParameters: params);
      return _parsePosts(response.data);
    } on DioException catch (e) {
      throw _mapDioError(e);
    }
  }

  /// Get posts sorted by hot score
  Future<PaginatedResponse<Post>> getPostsHot({int limit = 30, String? cursor}) async {
    try {
      final params = <String, dynamic>{'sort': 'hot', 'limit': limit};
      if (cursor != null) params['cursor'] = cursor;
      final response = await _dio.get('/posts', queryParameters: params);
      return _parsePosts(response.data);
    } on DioException catch (e) {
      throw _mapDioError(e);
    }
  }

  /// Get posts filtered by submolt name
  Future<PaginatedResponse<Post>> getSubmoltPosts(
    String submoltName, {
    String sort = 'hot',
    int limit = 30,
  }) async {
    try {
      final response = await _dio.get('/posts', queryParameters: {
        'sort': sort,
        'limit': limit,
        'submolt': submoltName,
      });
      return _parsePosts(response.data);
    } on DioException catch (e) {
      throw _mapDioError(e);
    }
  }

  // ==================== SINGLE POST ====================

  Future<Post> getPost(String postId) async {
    try {
      final response = await _dio.get('/posts/$postId');
      final data = response.data;
      // Real API returns { "success": true, "post": {...} }
      if (data is Map && data.containsKey('post')) {
        return Post.fromJson(data['post'] as Map<String, dynamic>);
      } else if (data is Map && data.containsKey('data')) {
        return Post.fromJson(data['data'] as Map<String, dynamic>);
      }
      return Post.fromJson(data as Map<String, dynamic>);
    } on DioException catch (e) {
      throw _mapDioError(e);
    }
  }

  Future<Post> createPost({
    required String title,
    required String content,
    required String submolt,
  }) async {
    try {
      final response = await _dio.post('/posts', data: {
        'title': title,
        'content': content,
        'submolt': submolt,
      });
      final data = response.data;
      if (data is Map && data.containsKey('post')) {
        return Post.fromJson(data['post'] as Map<String, dynamic>);
      } else if (data is Map && data.containsKey('data')) {
        return Post.fromJson(data['data'] as Map<String, dynamic>);
      }
      return Post.fromJson(data as Map<String, dynamic>);
    } on DioException catch (e) {
      throw _mapDioError(e);
    }
  }

  Future<void> deletePost(String postId) async {
    try {
      await _dio.delete('/posts/$postId');
    } on DioException catch (e) {
      throw _mapDioError(e);
    }
  }

  Future<void> upvotePost(String postId) async {
    try {
      await _dio.post('/posts/$postId/upvote');
    } on DioException catch (e) {
      throw _mapDioError(e);
    }
  }

  Future<void> downvotePost(String postId) async {
    try {
      await _dio.post('/posts/$postId/downvote');
    } on DioException catch (e) {
      throw _mapDioError(e);
    }
  }

  // ==================== COMMENTS ====================

  Future<List<Comment>> getComments(String postId, {String sort = 'best'}) async {
    try {
      final response = await _dio.get('/posts/$postId/comments', queryParameters: {
        'sort': sort,
        'limit': 50,
      });

      final data = response.data;
      List<dynamic> commentsList;

      if (data is Map) {
        // Real API returns { "success": true, "comments": [...] }
        if (data.containsKey('comments')) {
          commentsList = data['comments'] as List<dynamic>;
        } else if (data.containsKey('data')) {
          commentsList = data['data'] as List<dynamic>;
        } else {
          commentsList = [];
        }
      } else if (data is List) {
        commentsList = data;
      } else {
        commentsList = [];
      }

      return commentsList
          .map((c) => Comment.fromJson(c as Map<String, dynamic>))
          .toList();
    } on DioException catch (e) {
      throw _mapDioError(e);
    }
  }

  Future<Comment> createComment(String postId, String content) async {
    try {
      final response = await _dio.post('/posts/$postId/comments', data: {
        'content': content,
      });
      final data = response.data;
      if (data is Map && data.containsKey('comment')) {
        return Comment.fromJson(data['comment'] as Map<String, dynamic>);
      } else if (data is Map && data.containsKey('data')) {
        return Comment.fromJson(data['data'] as Map<String, dynamic>);
      }
      return Comment.fromJson(data as Map<String, dynamic>);
    } on DioException catch (e) {
      throw _mapDioError(e);
    }
  }

  Future<Comment> replyToComment(String commentId, String content) async {
    try {
      final response = await _dio.post('/comments/$commentId/reply', data: {
        'content': content,
      });
      final data = response.data;
      if (data is Map && data.containsKey('comment')) {
        return Comment.fromJson(data['comment'] as Map<String, dynamic>);
      } else if (data is Map && data.containsKey('data')) {
        return Comment.fromJson(data['data'] as Map<String, dynamic>);
      }
      return Comment.fromJson(data as Map<String, dynamic>);
    } on DioException catch (e) {
      throw _mapDioError(e);
    }
  }

  Future<void> upvoteComment(String commentId) async {
    try {
      await _dio.post('/comments/$commentId/upvote');
    } catch (_) {}
  }

  Future<void> downvoteComment(String commentId) async {
    try {
      await _dio.post('/comments/$commentId/downvote');
    } catch (_) {}
  }

  // ==================== SEARCH ====================

  /// Search posts — real endpoint: GET /search?q=...&type=posts
  Future<PaginatedResponse<Post>> searchPosts(String query, {int limit = 20}) async {
    try {
      final response = await _dio.get('/search', queryParameters: {
        'q': query,
        'type': 'posts',
        'limit': limit,
      });
      return _parseSearchResults(response.data, 'post');
    } on DioException catch (e) {
      throw _mapDioError(e);
    }
  }

  /// Search submolts — real endpoint: GET /search?q=...&type=submolts
  Future<List<Submolt>> searchSubmolts(String query, {int limit = 20}) async {
    try {
      final response = await _dio.get('/search', queryParameters: {
        'q': query,
        'type': 'submolts',
        'limit': limit,
      });

      final data = response.data;
      List<dynamic> resultsList;

      if (data is Map) {
        // Real API: { "success": true, "results": [...] }
        if (data.containsKey('results')) {
          resultsList = data['results'] as List<dynamic>;
        } else if (data.containsKey('submolts')) {
          resultsList = data['submolts'] as List<dynamic>;
        } else if (data.containsKey('data')) {
          resultsList = data['data'] as List<dynamic>;
        } else {
          resultsList = [];
        }
      } else if (data is List) {
        resultsList = data;
      } else {
        resultsList = [];
      }

      return resultsList
          .map((s) => Submolt.fromJson(s as Map<String, dynamic>))
          .toList();
    } on DioException catch (e) {
      throw _mapDioError(e);
    }
  }

  // ==================== SUBMOLTS ====================

  /// List popular submolts — real endpoint: GET /submolts
  Future<List<Submolt>> getSubmolts({int limit = 50}) async {
    try {
      final response = await _dio.get('/submolts', queryParameters: {
        'limit': limit,
      });

      final data = response.data;
      List<dynamic> list;

      if (data is Map) {
        // Real API: { "success": true, "submolts": [...] }
        if (data.containsKey('submolts')) {
          list = data['submolts'] as List<dynamic>;
        } else if (data.containsKey('data')) {
          list = data['data'] as List<dynamic>;
        } else {
          list = [];
        }
      } else if (data is List) {
        list = data;
      } else {
        list = [];
      }

      return list.map((s) => Submolt.fromJson(s as Map<String, dynamic>)).toList();
    } catch (_) {
      return [];
    }
  }

  Future<Submolt> createSubmolt({
    required String name,
    required String displayName,
    required String description,
  }) async {
    try {
      final response = await _dio.post('/submolts', data: {
        'name': name,
        'display_name': displayName,
        'description': description,
      });
      final data = response.data;
      if (data is Map && data.containsKey('submolt')) {
        return Submolt.fromJson(data['submolt'] as Map<String, dynamic>);
      } else if (data is Map && data.containsKey('data')) {
        return Submolt.fromJson(data['data'] as Map<String, dynamic>);
      }
      return Submolt.fromJson(data as Map<String, dynamic>);
    } on DioException catch (e) {
      throw _mapDioError(e);
    }
  }

  // ==================== PROFILE / MY POSTS ====================

  /// Fetch the current agent's own posts via search by name.
  /// NOTE: Moltbook has no /agents/me/posts endpoint as of 2026.
  /// Search by name is the only reliable method.
  Future<PaginatedResponse<Post>> getMyPosts({int limit = 50}) async {
    final auth = Get.find<AuthProvider>();
    final agentName = auth.currentAgent.value?.name ?? '';
    if (agentName.isEmpty) {
      return PaginatedResponse(data: []);
    }
    try {
      final response = await _dio.get('/search', queryParameters: {
        'q': agentName,
        'type': 'posts',
        'limit': limit,
      });
      // Return ALL results — do NOT filter by agentId because Moltbook
      // API returns empty agent_id fields in post responses.
      return _parseSearchResults(response.data, 'post');
    } on DioException catch (e) {
      throw _mapDioError(e);
    }
  }

  /// Moltbook API does NOT have a comment history endpoint as of 2026.
  /// Returns empty list immediately; callers should show a friendly message.
  Future<List<Comment>> getMyComments({int limit = 50}) async {
    throw Exception('feature_not_available');
  }

  Future<void> deleteComment(String commentId) async {
    try {
      await _dio.delete('/comments/$commentId');
    } on DioException catch (e) {
      throw _mapDioError(e);
    }
  }

  // ==================== HELPERS ====================

  PaginatedResponse<Post> _parsePosts(dynamic data) {
    List<dynamic> postsList;
    bool hasMore = false;
    String? nextCursor;

    if (data is Map) {
      // Real API: { "success": true, "posts": [...], "has_more": true, "next_cursor": "..." }
      if (data.containsKey('posts')) {
        postsList = data['posts'] as List<dynamic>;
      } else if (data.containsKey('data')) {
        postsList = data['data'] as List<dynamic>;
      } else {
        postsList = [];
      }
      hasMore = data['has_more'] == true;
      nextCursor = data['next_cursor']?.toString();
    } else if (data is List) {
      postsList = data;
    } else {
      postsList = [];
    }

    return PaginatedResponse(
      data: postsList
          .map((p) => Post.fromJson(p as Map<String, dynamic>))
          .toList(),
      hasMore: hasMore,
      nextCursor: nextCursor,
    );
  }

  PaginatedResponse<Post> _parseSearchResults(dynamic data, String type) {
    List<dynamic> resultsList;
    bool hasMore = false;

    if (data is Map) {
      // Real API: { "success": true, "results": [...], "has_more": true }
      if (data.containsKey('results')) {
        resultsList = data['results'] as List<dynamic>;
      } else if (data.containsKey('posts')) {
        resultsList = data['posts'] as List<dynamic>;
      } else if (data.containsKey('data')) {
        resultsList = data['data'] as List<dynamic>;
      } else {
        resultsList = [];
      }
      hasMore = data['has_more'] == true;
    } else if (data is List) {
      resultsList = data;
    } else {
      resultsList = [];
    }

    // Filter by type if mixed results
    if (type.isNotEmpty) {
      resultsList = resultsList
          .where((r) => r is Map && (r['type'] == type || r['type'] == null))
          .toList();
    }

    return PaginatedResponse(
      data: resultsList
          .map((r) => _searchResultToPost(r as Map<String, dynamic>))
          .where((p) => p != null)
          .cast<Post>()
          .toList(),
      hasMore: hasMore,
    );
  }

  Post? _searchResultToPost(Map<String, dynamic> json) {
    try {
      return Post.fromJson(json);
    } catch (_) {
      return null;
    }
  }

  Exception _mapDioError(DioException e) {
    if (e.type == DioExceptionType.connectionTimeout ||
        e.type == DioExceptionType.receiveTimeout ||
        e.type == DioExceptionType.sendTimeout) {
      return Exception('Request timed out. Please check your internet connection.');
    }
    if (e.type == DioExceptionType.connectionError) {
      return Exception('Cannot reach Moltbook servers. Check your connection.');
    }
    final status = e.response?.statusCode;
    if (status == 401) return Exception('Invalid or expired API key (401)');
    if (status == 403) return Exception('Access forbidden (403)');
    if (status == 404) return Exception('Not found (404)');
    if (status == 429) return Exception('Rate limited — too many requests (429)');
    if (status == 504 || status == 503 || status == 502) {
      return Exception('Moltbook server error ($status). Please try again.');
    }
    return Exception(e.message ?? 'Network error');
  }
}
