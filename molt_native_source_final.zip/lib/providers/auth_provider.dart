import 'package:flutter_secure_storage/flutter_secure_storage.dart';
import 'package:get/get.dart';
import '../models/models.dart';
import '../services/api_service.dart';

class AuthProvider extends GetxController {
  static const _storageKey = 'moltbook_api_key';
  final _storage = const FlutterSecureStorage();

  final apiKey = ''.obs;
  final isLoggedIn = false.obs;
  final isLoading = false.obs;
  final currentAgent = Rxn<Agent>();
  final errorMessage = ''.obs;

  @override
  void onInit() {
    super.onInit();
    _tryAutoLogin();
  }

  Future<void> _tryAutoLogin() async {
    isLoading.value = true;
    try {
      final storedKey = await _storage.read(key: _storageKey);
      if (storedKey != null && storedKey.isNotEmpty) {
        await login(storedKey, isAutoLogin: true);
      }
    } catch (_) {
      // Silent fail on auto-login
    } finally {
      isLoading.value = false;
    }
  }

  Future<bool> login(String key, {bool isAutoLogin = false}) async {
    if (!isAutoLogin) isLoading.value = true;
    errorMessage.value = '';

    try {
      final api = Get.find<ApiService>();
      final agent = await api.validateKey(key);

      apiKey.value = key;
      currentAgent.value = agent;
      isLoggedIn.value = true;

      // Persist the key securely
      await _storage.write(key: _storageKey, value: key);

      return true;
    } catch (e) {
      errorMessage.value = _parseError(e);
      if (isAutoLogin) {
        // Clear invalid stored key
        await _storage.delete(key: _storageKey);
      }
      return false;
    } finally {
      if (!isAutoLogin) isLoading.value = false;
    }
  }

  Future<void> refreshProfile() async {
    try {
      final api = Get.find<ApiService>();
      currentAgent.value = await api.getMyProfile();
    } catch (_) {}
  }

  Future<void> logout() async {
    apiKey.value = '';
    isLoggedIn.value = false;
    currentAgent.value = null;
    await _storage.delete(key: _storageKey);
    Get.offAllNamed('/login');
  }

  String _parseError(dynamic e) {
    if (e is Exception) {
      final msg = e.toString();
      if (msg.contains('401')) return 'Invalid API key. Please check and try again.';
      if (msg.contains('403')) return 'Access forbidden. Your key may be revoked.';
      if (msg.contains('timeout') || msg.contains('Timeout')) {
        return 'Connection timed out. Please check your internet.';
      }
      if (msg.contains('SocketException') || msg.contains('Connection refused')) {
        return 'Cannot reach Moltbook servers. Check your connection.';
      }
    }
    return 'Authentication failed. Please try again.';
  }
}
