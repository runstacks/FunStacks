import 'package:flutter/material.dart';
import 'package:get/get.dart';
import '../models/models.dart';
import '../services/api_service.dart';
import '../providers/auth_provider.dart';
import '../theme/app_theme.dart';
import '../widgets/post_card.dart';
import '../widgets/shimmer_widgets.dart';

class ProfileController extends GetxController
    with GetSingleTickerProviderStateMixin {
  late TabController tabController;
  final api = Get.find<ApiService>();
  final auth = Get.find<AuthProvider>();

  final myPosts = <Post>[].obs;
  final isLoadingPosts = true.obs;
  final errorPosts = ''.obs;

  final myComments = <Comment>[].obs;
  final isLoadingComments = false.obs;
  final errorComments = ''.obs;

  // Computed counts (since /agents/me may return 0 for these)
  final computedPostCount = 0.obs;
  final computedCommentCount = 0.obs;

  @override
  void onInit() {
    super.onInit();
    tabController = TabController(length: 2, vsync: this);
    auth.refreshProfile().then((_) {
      _loadMyPosts();
      _loadMyComments();
    });
  }

  @override
  void onClose() {
    tabController.dispose();
    super.onClose();
  }

  Future<void> _loadMyPosts() async {
    isLoadingPosts.value = true;
    errorPosts.value = '';
    try {
      final result = await api.getMyPosts(limit: 50);
      myPosts.assignAll(result.data);
      computedPostCount.value = result.data.length;
    } catch (e) {
      final msg = e.toString().replaceFirst('Exception: ', '');
      errorPosts.value = msg;
    } finally {
      isLoadingPosts.value = false;
    }
  }

  Future<void> _loadMyComments() async {
    isLoadingComments.value = true;
    errorComments.value = '';
    try {
      final result = await api.getMyComments(limit: 50);
      myComments.assignAll(result);
      computedCommentCount.value = result.length;
    } catch (e) {
      final msg = e.toString().replaceFirst('Exception: ', '');
      errorComments.value = msg;
    } finally {
      isLoadingComments.value = false;
    }
  }

  Future<void> refreshPosts() => _loadMyPosts();
  Future<void> refreshComments() => _loadMyComments();

  Future<void> deletePost(String postId) async {
    try {
      await api.deletePost(postId);
      myPosts.removeWhere((p) => p.id == postId);
      computedPostCount.value = myPosts.length;
      Get.snackbar(
        'Deleted',
        'Post removed successfully',
        backgroundColor: AppTheme.primary,
        colorText: Colors.black,
        snackPosition: SnackPosition.BOTTOM,
      );
    } catch (e) {
      Get.snackbar(
        'Error',
        e.toString().replaceFirst('Exception: ', ''),
        backgroundColor: AppTheme.accent,
        colorText: Colors.white,
        snackPosition: SnackPosition.BOTTOM,
      );
    }
  }

  Future<void> deleteComment(String commentId) async {
    try {
      await api.deleteComment(commentId);
      myComments.removeWhere((c) => c.id == commentId);
      computedCommentCount.value = myComments.length;
      Get.snackbar(
        'Deleted',
        'Comment removed',
        backgroundColor: AppTheme.primary,
        colorText: Colors.black,
        snackPosition: SnackPosition.BOTTOM,
      );
    } catch (e) {
      Get.snackbar(
        'Error',
        e.toString().replaceFirst('Exception: ', ''),
        backgroundColor: AppTheme.accent,
        colorText: Colors.white,
        snackPosition: SnackPosition.BOTTOM,
      );
    }
  }
}

class ProfileScreen extends StatelessWidget {
  const ProfileScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final controller = Get.put(ProfileController());
    final auth = Get.find<AuthProvider>();

    return Scaffold(
      appBar: AppBar(
        title: const Text('Agent Identity'),
        actions: [
          IconButton(
            icon: const Icon(Icons.refresh_rounded, color: AppTheme.primary),
            onPressed: () {
              auth.refreshProfile();
              controller.refreshPosts();
              controller.refreshComments();
            },
          ),
          IconButton(
            icon: const Icon(Icons.logout_rounded, color: AppTheme.accent),
            onPressed: () => _showLogoutDialog(context, auth),
          ),
        ],
      ),
      body: Obx(() {
        final agent = auth.currentAgent.value;
        if (agent == null) {
          return const Center(
            child: CircularProgressIndicator(color: AppTheme.primary),
          );
        }

        return NestedScrollView(
          headerSliverBuilder: (context, innerBoxIsScrolled) => [
            SliverToBoxAdapter(
                child: _buildProfileHeader(context, agent, controller)),
            SliverPersistentHeader(
              pinned: true,
              delegate: _TabBarDelegate(
                TabBar(
                  controller: controller.tabController,
                  tabs: const [
                    Tab(text: 'My Posts'),
                    Tab(text: 'My Replies'),
                  ],
                ),
              ),
            ),
          ],
          body: TabBarView(
            controller: controller.tabController,
            children: [
              // ── MY POSTS TAB ──────────────────────────────────
              _buildMyPostsTab(context, controller, agent),

              // ── MY REPLIES TAB ────────────────────────────────
              _buildMyRepliesTab(context, controller, agent),
            ],
          ),
        );
      }),
    );
  }

  Widget _buildMyPostsTab(
      BuildContext context, ProfileController controller, Agent agent) {
    return Obx(() {
      if (controller.isLoadingPosts.value) {
        return const FeedSkeleton(itemCount: 3);
      }

      if (controller.errorPosts.value.isNotEmpty) {
        return Center(
          child: Padding(
            padding: const EdgeInsets.all(24),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                const Icon(Icons.error_outline_rounded,
                    color: AppTheme.accent, size: 40),
                const SizedBox(height: 12),
                Text(
                  controller.errorPosts.value,
                  style: const TextStyle(color: AppTheme.textSecondary),
                  textAlign: TextAlign.center,
                ),
                const SizedBox(height: 16),
                ElevatedButton.icon(
                  onPressed: controller.refreshPosts,
                  icon: const Icon(Icons.refresh_rounded),
                  label: const Text('Retry'),
                ),
              ],
            ),
          ),
        );
      }

      if (controller.myPosts.isEmpty) {
        return Center(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Icon(Icons.article_outlined,
                  size: 56,
                  color: AppTheme.textMuted.withValues(alpha: 0.4)),
              const SizedBox(height: 16),
              const Text(
                'No posts found',
                style: TextStyle(color: AppTheme.textMuted, fontSize: 16),
              ),
              const SizedBox(height: 6),
              const Text(
                'Your published posts will appear here',
                style: TextStyle(color: AppTheme.textMuted, fontSize: 12),
              ),
              const SizedBox(height: 16),
              ElevatedButton.icon(
                onPressed: () => Get.toNamed('/compose'),
                icon: const Icon(Icons.edit_rounded),
                label: const Text('Write a Post'),
              ),
            ],
          ),
        );
      }

      return RefreshIndicator(
        onRefresh: controller.refreshPosts,
        color: AppTheme.primary,
        backgroundColor: AppTheme.surface,
        child: ListView.builder(
          padding: const EdgeInsets.only(top: 8, bottom: 20),
          itemCount: controller.myPosts.length,
          itemBuilder: (context, index) {
            final post = controller.myPosts[index];
            return PostCard(
              post: post,
              currentAgentId: agent.agentId,
              onTap: () =>
                  Get.toNamed('/post/${post.id}', arguments: post),
              onDelete: () =>
                  _confirmDeletePost(context, controller, post.id),
            );
          },
        ),
      );
    });
  }

  Widget _buildMyRepliesTab(
      BuildContext context, ProfileController controller, Agent agent) {
    return Obx(() {
      if (controller.isLoadingComments.value) {
        return Column(
          children: List.generate(4, (_) => const CommentSkeleton()),
        );
      }

      // Moltbook API doesn't have a comment history endpoint yet
      if (controller.errorComments.value == 'feature_not_available') {
        return Center(
          child: Padding(
            padding: const EdgeInsets.all(32),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Container(
                  padding: const EdgeInsets.all(20),
                  decoration: BoxDecoration(
                    color: AppTheme.primary.withValues(alpha: 0.08),
                    shape: BoxShape.circle,
                    border: Border.all(
                        color: AppTheme.primary.withValues(alpha: 0.2),
                        width: 2),
                  ),
                  child: const Icon(Icons.chat_bubble_outline_rounded,
                      size: 40, color: AppTheme.primary),
                ),
                const SizedBox(height: 20),
                const Text(
                  'Comment History Unavailable',
                  style: TextStyle(
                    color: AppTheme.textPrimary,
                    fontSize: 17,
                    fontWeight: FontWeight.w700,
                  ),
                ),
                const SizedBox(height: 10),
                const Text(
                  'Moltbook does not yet provide an API endpoint for comment history. This is a known platform limitation requested by the agent community.',
                  style: TextStyle(
                      color: AppTheme.textSecondary,
                      fontSize: 13,
                      height: 1.6),
                  textAlign: TextAlign.center,
                ),
                const SizedBox(height: 20),
                Container(
                  padding: const EdgeInsets.symmetric(
                      horizontal: 14, vertical: 10),
                  decoration: BoxDecoration(
                    color: AppTheme.surfaceLight,
                    borderRadius: BorderRadius.circular(10),
                    border: Border.all(
                        color: AppTheme.divider.withValues(alpha: 0.4)),
                  ),
                  child: const Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Icon(Icons.info_outline_rounded,
                          size: 14, color: AppTheme.textMuted),
                      SizedBox(width: 8),
                      Text(
                        'Tracked on Moltbook API wishlist',
                        style: TextStyle(
                            color: AppTheme.textMuted, fontSize: 12),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
        );
      }

      if (controller.errorComments.value.isNotEmpty) {
        return Center(
          child: Padding(
            padding: const EdgeInsets.all(24),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                const Icon(Icons.error_outline_rounded,
                    color: AppTheme.accent, size: 40),
                const SizedBox(height: 12),
                Text(
                  controller.errorComments.value,
                  style: const TextStyle(color: AppTheme.textSecondary),
                  textAlign: TextAlign.center,
                ),
                const SizedBox(height: 16),
                ElevatedButton.icon(
                  onPressed: controller.refreshComments,
                  icon: const Icon(Icons.refresh_rounded),
                  label: const Text('Retry'),
                ),
              ],
            ),
          ),
        );
      }

      if (controller.myComments.isEmpty) {
        return Center(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Icon(Icons.chat_bubble_outline_rounded,
                  size: 56,
                  color: AppTheme.textMuted.withValues(alpha: 0.4)),
              const SizedBox(height: 16),
              const Text(
                'No replies found',
                style: TextStyle(color: AppTheme.textMuted, fontSize: 16),
              ),
            ],
          ),
        );
      }

      return RefreshIndicator(
        onRefresh: controller.refreshComments,
        color: AppTheme.primary,
        backgroundColor: AppTheme.surface,
        child: ListView.builder(
          padding: const EdgeInsets.only(top: 8, bottom: 20),
          itemCount: controller.myComments.length,
          itemBuilder: (context, index) {
            final comment = controller.myComments[index];
            return _CommentHistoryCard(
              comment: comment,
              onDelete: () =>
                  _confirmDeleteComment(context, controller, comment.id),
            );
          },
        ),
      );
    });
  }

  Widget _buildProfileHeader(
      BuildContext context, Agent agent, ProfileController controller) {
    return Container(
      padding: const EdgeInsets.fromLTRB(20, 16, 20, 20),
      decoration: BoxDecoration(
        gradient: LinearGradient(
          begin: Alignment.topCenter,
          end: Alignment.bottomCenter,
          colors: [
            AppTheme.primary.withValues(alpha: 0.08),
            AppTheme.background,
          ],
        ),
      ),
      child: Column(
        children: [
          // Avatar
          _buildAvatar(agent, 40),
          const SizedBox(height: 14),

          // Name + verified badge
          Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Flexible(
                child: Text(
                  agent.name,
                  style: const TextStyle(
                    color: AppTheme.textPrimary,
                    fontSize: 22,
                    fontWeight: FontWeight.w700,
                  ),
                  textAlign: TextAlign.center,
                ),
              ),
              if (agent.verified) ...[
                const SizedBox(width: 8),
                Container(
                  padding:
                      const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
                  decoration: BoxDecoration(
                    color: AppTheme.primary.withValues(alpha: 0.15),
                    borderRadius: BorderRadius.circular(12),
                    border: Border.all(
                        color: AppTheme.primary.withValues(alpha: 0.3)),
                  ),
                  child: const Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Icon(Icons.verified_rounded,
                          size: 14, color: AppTheme.primary),
                      SizedBox(width: 4),
                      Text(
                        'Claimed',
                        style: TextStyle(
                            color: AppTheme.primary,
                            fontSize: 11,
                            fontWeight: FontWeight.w600),
                      ),
                    ],
                  ),
                ),
              ],
            ],
          ),
          const SizedBox(height: 6),

          // Bio snippet
          if (agent.bio != null && agent.bio!.isNotEmpty) ...[
            Text(
              agent.bio!,
              style: const TextStyle(
                  color: AppTheme.textSecondary, fontSize: 13, height: 1.5),
              textAlign: TextAlign.center,
              maxLines: 3,
              overflow: TextOverflow.ellipsis,
            ),
            const SizedBox(height: 14),
          ],

          // Quick stats row — use computed counts
          Obx(() => Row(
                mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                children: [
                  _QuickStat(
                      label: 'Karma',
                      value: _formatNumber(agent.karma),
                      color: const Color(0xFFFFCA28)),
                  _QuickStat(
                      label: 'Posts',
                      value: _formatNumber(controller.computedPostCount.value > 0
                          ? controller.computedPostCount.value
                          : agent.postCount),
                      color: AppTheme.primary),
                  _QuickStat(
                      label: 'Comments',
                      value: _formatNumber(
                          controller.computedCommentCount.value > 0
                              ? controller.computedCommentCount.value
                              : agent.commentCount),
                      color: const Color(0xFF42A5F5)),
                  _QuickStat(
                      label: 'Followers',
                      value: _formatNumber(agent.followerCount),
                      color: const Color(0xFFAB47BC)),
                ],
              )),

          const SizedBox(height: 12),

          // Member since
          if (agent.createdAt.isNotEmpty)
            Text(
              'Member since ${_formatDate(agent.createdAt)}',
              style: const TextStyle(color: AppTheme.textMuted, fontSize: 11),
            ),
        ],
      ),
    );
  }

  Widget _buildAvatar(Agent agent, double radius) {
    if (agent.avatarUrl != null && agent.avatarUrl!.isNotEmpty) {
      return CircleAvatar(
        radius: radius,
        backgroundImage: NetworkImage(agent.avatarUrl!),
        backgroundColor: AppTheme.surfaceLight,
      );
    }
    return CircleAvatar(
      radius: radius,
      backgroundColor: AppTheme.primary.withValues(alpha: 0.2),
      child: Text(
        agent.name.isNotEmpty ? agent.name[0].toUpperCase() : '?',
        style: TextStyle(
          color: AppTheme.primary,
          fontWeight: FontWeight.w700,
          fontSize: radius * 0.8,
        ),
      ),
    );
  }

  String _formatNumber(int n) {
    if (n >= 1000000) return '${(n / 1000000).toStringAsFixed(1)}M';
    if (n >= 1000) return '${(n / 1000).toStringAsFixed(1)}K';
    return n.toString();
  }

  String _formatDate(String iso) {
    try {
      final dt = DateTime.parse(iso);
      const months = [
        'Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun',
        'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'
      ];
      return '${months[dt.month - 1]} ${dt.day}, ${dt.year}';
    } catch (_) {
      return iso;
    }
  }

  void _confirmDeletePost(
      BuildContext context, ProfileController controller, String postId) {
    showDialog(
      context: context,
      builder: (ctx) => AlertDialog(
        backgroundColor: AppTheme.surface,
        title: const Text('Delete Post',
            style: TextStyle(color: AppTheme.textPrimary)),
        content: const Text(
          'Are you sure? This cannot be undone.',
          style: TextStyle(color: AppTheme.textSecondary),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(ctx),
            child: const Text('Cancel',
                style: TextStyle(color: AppTheme.textMuted)),
          ),
          TextButton(
            onPressed: () {
              Navigator.pop(ctx);
              controller.deletePost(postId);
            },
            child: const Text('Delete',
                style: TextStyle(color: AppTheme.accent)),
          ),
        ],
      ),
    );
  }

  void _confirmDeleteComment(
      BuildContext context, ProfileController controller, String commentId) {
    showDialog(
      context: context,
      builder: (ctx) => AlertDialog(
        backgroundColor: AppTheme.surface,
        title: const Text('Delete Comment',
            style: TextStyle(color: AppTheme.textPrimary)),
        content: const Text(
          'Are you sure? This cannot be undone.',
          style: TextStyle(color: AppTheme.textSecondary),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(ctx),
            child: const Text('Cancel',
                style: TextStyle(color: AppTheme.textMuted)),
          ),
          TextButton(
            onPressed: () {
              Navigator.pop(ctx);
              controller.deleteComment(commentId);
            },
            child: const Text('Delete',
                style: TextStyle(color: AppTheme.accent)),
          ),
        ],
      ),
    );
  }

  void _showLogoutDialog(BuildContext context, AuthProvider auth) {
    showDialog(
      context: context,
      builder: (ctx) => AlertDialog(
        backgroundColor: AppTheme.surface,
        title: const Text('Logout',
            style: TextStyle(color: AppTheme.textPrimary)),
        content: const Text(
          'You will need to re-enter your API key to log back in.',
          style: TextStyle(color: AppTheme.textSecondary),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(ctx),
            child: const Text('Cancel',
                style: TextStyle(color: AppTheme.textMuted)),
          ),
          TextButton(
            onPressed: () {
              Navigator.pop(ctx);
              auth.logout();
            },
            child: const Text('Logout',
                style: TextStyle(color: AppTheme.accent)),
          ),
        ],
      ),
    );
  }
}

// ── Comment history card (used in My Replies tab) ──────────────────────────

class _CommentHistoryCard extends StatelessWidget {
  final Comment comment;
  final VoidCallback? onDelete;

  const _CommentHistoryCard({required this.comment, this.onDelete});

  @override
  Widget build(BuildContext context) {
    final createdAt = DateTime.tryParse(comment.createdAt);
    final timeAgo =
        createdAt != null ? _timeAgo(createdAt) : '';

    return Container(
      margin: const EdgeInsets.symmetric(horizontal: 12, vertical: 5),
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: AppTheme.cardColor.withValues(alpha: 0.85),
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: AppTheme.divider.withValues(alpha: 0.35)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // Header row
          Row(
            children: [
              const Icon(Icons.chat_bubble_outline_rounded,
                  size: 14, color: AppTheme.primary),
              const SizedBox(width: 6),
              Text(
                timeAgo,
                style: const TextStyle(
                    color: AppTheme.textMuted, fontSize: 11),
              ),
              const Spacer(),
              // Score badge
              Container(
                padding:
                    const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
                decoration: BoxDecoration(
                  color: AppTheme.surfaceLight,
                  borderRadius: BorderRadius.circular(10),
                ),
                child: Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Icon(Icons.arrow_upward_rounded,
                        size: 12,
                        color: comment.score >= 0
                            ? AppTheme.upvote
                            : AppTheme.downvote),
                    const SizedBox(width: 3),
                    Text(
                      comment.score.toString(),
                      style: TextStyle(
                        color: comment.score >= 0
                            ? AppTheme.upvote
                            : AppTheme.downvote,
                        fontSize: 11,
                        fontWeight: FontWeight.w700,
                      ),
                    ),
                  ],
                ),
              ),
              if (onDelete != null) ...[
                const SizedBox(width: 8),
                InkWell(
                  onTap: onDelete,
                  borderRadius: BorderRadius.circular(20),
                  child: const Padding(
                    padding: EdgeInsets.all(4),
                    child: Icon(Icons.delete_outline_rounded,
                        size: 18, color: AppTheme.accent),
                  ),
                ),
              ],
            ],
          ),
          const SizedBox(height: 8),

          // Comment content
          Text(
            comment.content,
            style: const TextStyle(
              color: AppTheme.textSecondary,
              fontSize: 14,
              height: 1.5,
            ),
            maxLines: 6,
            overflow: TextOverflow.ellipsis,
          ),
        ],
      ),
    );
  }

  String _timeAgo(DateTime dt) {
    final diff = DateTime.now().difference(dt);
    if (diff.inDays > 365) return '${(diff.inDays / 365).floor()}y ago';
    if (diff.inDays > 30) return '${(diff.inDays / 30).floor()}mo ago';
    if (diff.inDays > 0) return '${diff.inDays}d ago';
    if (diff.inHours > 0) return '${diff.inHours}h ago';
    if (diff.inMinutes > 0) return '${diff.inMinutes}m ago';
    return 'just now';
  }
}

// ── Helper widgets ──────────────────────────────────────────────────────────

class _QuickStat extends StatelessWidget {
  final String label;
  final String value;
  final Color color;

  const _QuickStat({
    required this.label,
    required this.value,
    required this.color,
  });

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        Text(
          value,
          style: TextStyle(
            color: color,
            fontWeight: FontWeight.w700,
            fontSize: 16,
          ),
        ),
        const SizedBox(height: 2),
        Text(
          label,
          style: const TextStyle(color: AppTheme.textMuted, fontSize: 10),
        ),
      ],
    );
  }
}

class _TabBarDelegate extends SliverPersistentHeaderDelegate {
  final TabBar tabBar;
  _TabBarDelegate(this.tabBar);

  @override
  Widget build(
      BuildContext context, double shrinkOffset, bool overlapsContent) {
    return Container(
      color: AppTheme.background,
      child: tabBar,
    );
  }

  @override
  double get maxExtent => tabBar.preferredSize.height;

  @override
  double get minExtent => tabBar.preferredSize.height;

  @override
  bool shouldRebuild(covariant _TabBarDelegate oldDelegate) => false;
}
