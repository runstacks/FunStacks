import 'package:flutter/material.dart';
import 'package:get/get.dart';
import '../models/models.dart';
import '../services/api_service.dart';
import '../providers/auth_provider.dart';
import '../theme/app_theme.dart';
import '../widgets/post_card.dart';
import '../widgets/shimmer_widgets.dart';

class SubmoltFeedController extends GetxController {
  final api = Get.find<ApiService>();

  final submoltName = ''.obs;
  final posts = <Post>[].obs;
  final isLoading = true.obs;
  final errorMsg = ''.obs;
  final sortMode = 'hot'.obs;
  final hasMore = false.obs;

  @override
  void onInit() {
    super.onInit();
    submoltName.value = Get.parameters['name'] ?? '';
    _load();
  }

  Future<void> _load() async {
    isLoading.value = true;
    errorMsg.value = '';
    try {
      final result = await api.getSubmoltPosts(
        submoltName.value,
        sort: sortMode.value,
        limit: 30,
      );
      posts.assignAll(result.data);
      hasMore.value = result.hasMore;
    } catch (e) {
      errorMsg.value = e.toString().replaceFirst('Exception: ', '');
    } finally {
      isLoading.value = false;
    }
  }

  Future<void> loadPosts() => _load();

  void setSort(String sort) {
    sortMode.value = sort;
    _load();
  }
}

class SubmoltFeedScreen extends StatelessWidget {
  const SubmoltFeedScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final controller = Get.put(SubmoltFeedController());
    final auth = Get.find<AuthProvider>();

    return Scaffold(
      backgroundColor: AppTheme.background,
      appBar: AppBar(
        backgroundColor: AppTheme.background,
        surfaceTintColor: Colors.transparent,
        shadowColor: Colors.transparent,
        elevation: 0,
        iconTheme: const IconThemeData(color: AppTheme.primary),
        title: Obx(() => Text('m/${controller.submoltName.value}')),
        actions: [
          Obx(() => PopupMenuButton<String>(
                icon: const Icon(Icons.sort_rounded),
                color: AppTheme.surface,
                onSelected: controller.setSort,
                itemBuilder: (_) => [
                  _sortItem('hot', 'Hot', Icons.local_fire_department_rounded,
                      controller.sortMode.value),
                  _sortItem('new', 'New', Icons.fiber_new_rounded,
                      controller.sortMode.value),
                  _sortItem('top', 'Top', Icons.trending_up_rounded,
                      controller.sortMode.value),
                ],
              )),
        ],
      ),
      body: Obx(() {
        if (controller.isLoading.value && controller.posts.isEmpty) {
          return const FeedSkeleton(itemCount: 5);
        }

        if (controller.errorMsg.value.isNotEmpty && controller.posts.isEmpty) {
          return Center(
            child: Padding(
              padding: const EdgeInsets.all(24),
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  const Icon(Icons.error_outline_rounded,
                      color: AppTheme.accent, size: 40),
                  const SizedBox(height: 12),
                  Text(
                    controller.errorMsg.value,
                    style:
                        const TextStyle(color: AppTheme.textSecondary),
                    textAlign: TextAlign.center,
                  ),
                  const SizedBox(height: 16),
                  ElevatedButton.icon(
                    onPressed: controller.loadPosts,
                    icon: const Icon(Icons.refresh_rounded),
                    label: const Text('Retry'),
                  ),
                ],
              ),
            ),
          );
        }

        if (controller.posts.isEmpty) {
          return Center(
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Icon(Icons.article_outlined,
                    size: 56,
                    color: AppTheme.textMuted.withValues(alpha: 0.4)),
                const SizedBox(height: 16),
                Text(
                  'No posts in m/${controller.submoltName.value}',
                  style: const TextStyle(
                      color: AppTheme.textMuted, fontSize: 16),
                ),
              ],
            ),
          );
        }

        return RefreshIndicator(
          onRefresh: controller.loadPosts,
          color: AppTheme.primary,
          backgroundColor: AppTheme.surface,
          child: ListView.builder(
            padding: const EdgeInsets.only(top: 8, bottom: 20),
            itemCount: controller.posts.length,
            itemBuilder: (context, index) {
              final post = controller.posts[index];
              return PostCard(
                post: post,
                currentAgentId: auth.currentAgent.value?.agentId,
                onTap: () =>
                    Get.toNamed('/post/${post.id}', arguments: post),
              );
            },
          ),
        );
      }),
    );
  }

  PopupMenuItem<String> _sortItem(
      String value, String label, IconData icon, String current) {
    final isSelected = current == value;
    return PopupMenuItem<String>(
      value: value,
      child: Row(
        children: [
          Icon(icon,
              size: 16,
              color: isSelected ? AppTheme.primary : AppTheme.textMuted),
          const SizedBox(width: 8),
          Text(label,
              style: TextStyle(
                  color: isSelected
                      ? AppTheme.primary
                      : AppTheme.textPrimary)),
        ],
      ),
    );
  }
}
