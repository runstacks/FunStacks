import 'package:flutter/material.dart';
import 'package:get/get.dart';
import '../models/models.dart';
import '../services/api_service.dart';
import '../providers/auth_provider.dart';
import '../theme/app_theme.dart';
import '../widgets/post_card.dart';
import '../widgets/shimmer_widgets.dart';

class FeedController extends GetxController with GetSingleTickerProviderStateMixin {
  late TabController tabController;
  final api = Get.find<ApiService>();
  final auth = Get.find<AuthProvider>();

  final latestPosts = <Post>[].obs;
  final topPosts = <Post>[].obs;
  final hotPosts = <Post>[].obs;

  final isLoadingLatest = true.obs;
  final isLoadingTop = true.obs;
  final isLoadingHot = true.obs;

  final errorLatest = ''.obs;
  final errorTop = ''.obs;
  final errorHot = ''.obs;

  @override
  void onInit() {
    super.onInit();
    tabController = TabController(length: 3, vsync: this);
    fetchLatest();
    fetchTop();
    fetchHot();
  }

  @override
  void onClose() {
    tabController.dispose();
    super.onClose();
  }

  Future<void> fetchLatest() async {
    isLoadingLatest.value = true;
    errorLatest.value = '';
    try {
      final result = await api.getPostsNew(limit: 30);
      latestPosts.assignAll(result.data);
    } catch (e) {
      errorLatest.value = e.toString().replaceFirst('Exception: ', '');
    } finally {
      isLoadingLatest.value = false;
    }
  }

  Future<void> fetchTop() async {
    isLoadingTop.value = true;
    errorTop.value = '';
    try {
      final result = await api.getPostsTop(limit: 30);
      topPosts.assignAll(result.data);
    } catch (e) {
      errorTop.value = e.toString().replaceFirst('Exception: ', '');
    } finally {
      isLoadingTop.value = false;
    }
  }

  Future<void> fetchHot() async {
    isLoadingHot.value = true;
    errorHot.value = '';
    try {
      final result = await api.getPostsHot(limit: 30);
      hotPosts.assignAll(result.data);
    } catch (e) {
      errorHot.value = e.toString().replaceFirst('Exception: ', '');
    } finally {
      isLoadingHot.value = false;
    }
  }

  Future<void> refreshAll() async {
    await Future.wait([fetchLatest(), fetchTop(), fetchHot()]);
  }
}

class FeedScreen extends StatelessWidget {
  const FeedScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final controller = Get.put(FeedController());

    return Scaffold(
      appBar: AppBar(
        title: Row(
          children: [
            Icon(Icons.smart_toy_rounded, color: AppTheme.primary, size: 24),
            const SizedBox(width: 8),
            const Text('Moltbook'),
          ],
        ),
        actions: [
          IconButton(
            icon: const Icon(Icons.search_rounded),
            onPressed: () => Get.toNamed('/search'),
          ),
          IconButton(
            icon: const Icon(Icons.person_outline_rounded),
            onPressed: () => Get.toNamed('/profile'),
          ),
        ],
        bottom: TabBar(
          controller: controller.tabController,
          tabs: const [
            Tab(text: '🆕 Latest'),
            Tab(text: '🔥 Top'),
            Tab(text: '⚡ Hot'),
          ],
        ),
      ),
      body: TabBarView(
        controller: controller.tabController,
        children: [
          _FeedTab(
            posts: controller.latestPosts,
            isLoading: controller.isLoadingLatest,
            error: controller.errorLatest,
            onRefresh: controller.fetchLatest,
          ),
          _FeedTab(
            posts: controller.topPosts,
            isLoading: controller.isLoadingTop,
            error: controller.errorTop,
            onRefresh: controller.fetchTop,
          ),
          _FeedTab(
            posts: controller.hotPosts,
            isLoading: controller.isLoadingHot,
            error: controller.errorHot,
            onRefresh: controller.fetchHot,
          ),
        ],
      ),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: () => Get.toNamed('/compose'),
        icon: const Icon(Icons.edit_rounded),
        label: const Text('Post'),
      ),
    );
  }
}

class _FeedTab extends StatelessWidget {
  final RxList<Post> posts;
  final RxBool isLoading;
  final RxString error;
  final Future<void> Function() onRefresh;

  const _FeedTab({
    required this.posts,
    required this.isLoading,
    required this.error,
    required this.onRefresh,
  });

  @override
  Widget build(BuildContext context) {
    return Obx(() {
      if (isLoading.value) {
        return const FeedSkeleton();
      }

      if (error.value.isNotEmpty) {
        return Center(
          child: Padding(
            padding: const EdgeInsets.all(24),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                const Icon(Icons.error_outline_rounded,
                    color: AppTheme.accent, size: 48),
                const SizedBox(height: 16),
                Text(
                  error.value,
                  style: const TextStyle(color: AppTheme.textSecondary),
                  textAlign: TextAlign.center,
                ),
                const SizedBox(height: 16),
                ElevatedButton.icon(
                  onPressed: onRefresh,
                  icon: const Icon(Icons.refresh_rounded),
                  label: const Text('Retry'),
                ),
              ],
            ),
          ),
        );
      }

      if (posts.isEmpty) {
        return Center(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Icon(Icons.inbox_rounded,
                  color: AppTheme.textMuted.withValues(alpha: 0.5), size: 64),
              const SizedBox(height: 16),
              const Text('No posts yet',
                  style: TextStyle(color: AppTheme.textSecondary, fontSize: 16)),
              const SizedBox(height: 12),
              ElevatedButton.icon(
                onPressed: onRefresh,
                icon: const Icon(Icons.refresh_rounded),
                label: const Text('Refresh'),
              ),
            ],
          ),
        );
      }

      final auth = Get.find<AuthProvider>();
      return RefreshIndicator(
        onRefresh: onRefresh,
        color: AppTheme.primary,
        backgroundColor: AppTheme.surface,
        child: ListView.builder(
          physics: const AlwaysScrollableScrollPhysics(),
          padding: const EdgeInsets.only(top: 8, bottom: 80),
          itemCount: posts.length,
          itemBuilder: (context, index) {
            final post = posts[index];
            return PostCard(
              post: post,
              currentAgentId: auth.currentAgent.value?.agentId,
              onTap: () => Get.toNamed('/post/${post.id}', arguments: post),
              onSubmoltTap: () {},
            );
          },
        ),
      );
    });
  }
}
