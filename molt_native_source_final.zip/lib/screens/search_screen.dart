import 'package:flutter/material.dart';
import 'package:get/get.dart';
import '../models/models.dart';
import '../services/api_service.dart';
import '../theme/app_theme.dart';
import '../widgets/post_card.dart';
import '../widgets/shimmer_widgets.dart';
import '../providers/auth_provider.dart';

class MoltSearchController extends GetxController {
  final api = Get.find<ApiService>();
  final searchQuery = ''.obs;
  final searchType = 'posts'.obs;

  final postResults = <Post>[].obs;
  final submoltResults = <Submolt>[].obs;
  final isLoading = false.obs;
  final hasSearched = false.obs;
  final errorMsg = ''.obs;

  final queryController = TextEditingController();

  @override
  void onClose() {
    queryController.dispose();
    super.onClose();
  }

  Future<void> search() async {
    final query = queryController.text.trim();
    if (query.isEmpty) return;

    searchQuery.value = query;
    isLoading.value = true;
    hasSearched.value = true;
    errorMsg.value = '';
    postResults.clear();
    submoltResults.clear();

    try {
      if (searchType.value == 'posts') {
        final result = await api.searchPosts(query, limit: 20);
        postResults.assignAll(result.data);
      } else {
        final result = await api.searchSubmolts(query, limit: 20);
        submoltResults.assignAll(result);
      }
    } catch (e) {
      errorMsg.value = e.toString().replaceFirst('Exception: ', '');
    } finally {
      isLoading.value = false;
    }
  }

  void switchType(String type) {
    searchType.value = type;
    if (hasSearched.value && queryController.text.trim().isNotEmpty) {
      search();
    }
  }
}

class SearchScreen extends StatelessWidget {
  const SearchScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final controller = Get.put(MoltSearchController());
    final auth = Get.find<AuthProvider>();

    return Scaffold(
      appBar: AppBar(
        title: const Text('Search'),
      ),
      body: Column(
        children: [
          // Search bar
          Padding(
            padding: const EdgeInsets.fromLTRB(16, 8, 16, 0),
            child: TextField(
              controller: controller.queryController,
              style: const TextStyle(color: AppTheme.textPrimary, fontSize: 15),
              decoration: InputDecoration(
                hintText: 'Search Moltbook...',
                prefixIcon: const Icon(Icons.search_rounded,
                    color: AppTheme.primary, size: 22),
                suffixIcon: Obx(() => controller.searchQuery.isNotEmpty
                    ? IconButton(
                        icon: const Icon(Icons.clear_rounded,
                            color: AppTheme.textMuted, size: 20),
                        onPressed: () {
                          controller.queryController.clear();
                          controller.searchQuery.value = '';
                          controller.postResults.clear();
                          controller.submoltResults.clear();
                          controller.hasSearched.value = false;
                          controller.errorMsg.value = '';
                        },
                      )
                    : const SizedBox.shrink()),
              ),
              onSubmitted: (_) => controller.search(),
              textInputAction: TextInputAction.search,
            ),
          ),

          // Type toggle
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
            child: Obx(() => Row(
                  children: [
                    _TypeChip(
                      label: 'Posts',
                      icon: Icons.article_outlined,
                      isSelected: controller.searchType.value == 'posts',
                      onTap: () => controller.switchType('posts'),
                    ),
                    const SizedBox(width: 8),
                    _TypeChip(
                      label: 'Submolts',
                      icon: Icons.group_outlined,
                      isSelected: controller.searchType.value == 'submolts',
                      onTap: () => controller.switchType('submolts'),
                    ),
                  ],
                )),
          ),

          const Divider(height: 1),

          // Results
          Expanded(
            child: Obx(() {
              if (controller.isLoading.value) {
                return controller.searchType.value == 'posts'
                    ? const FeedSkeleton(itemCount: 4)
                    : const Center(
                        child: CircularProgressIndicator(
                            color: AppTheme.primary));
              }

              if (controller.errorMsg.value.isNotEmpty) {
                return Center(
                  child: Padding(
                    padding: const EdgeInsets.all(24),
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        const Icon(Icons.error_outline_rounded,
                            color: AppTheme.accent, size: 40),
                        const SizedBox(height: 12),
                        Text(
                          controller.errorMsg.value,
                          style: const TextStyle(color: AppTheme.textSecondary),
                          textAlign: TextAlign.center,
                        ),
                        const SizedBox(height: 16),
                        ElevatedButton.icon(
                          onPressed: controller.search,
                          icon: const Icon(Icons.refresh_rounded),
                          label: const Text('Retry'),
                        ),
                      ],
                    ),
                  ),
                );
              }

              if (!controller.hasSearched.value) {
                return Center(
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Icon(Icons.search_rounded,
                          size: 64,
                          color: AppTheme.textMuted.withValues(alpha: 0.3)),
                      const SizedBox(height: 16),
                      const Text(
                        'Search for posts or submolts',
                        style: TextStyle(
                            color: AppTheme.textMuted, fontSize: 16),
                      ),
                    ],
                  ),
                );
              }

              if (controller.searchType.value == 'posts') {
                return _buildPostResults(controller, auth);
              } else {
                return _buildSubmoltResults(controller);
              }
            }),
          ),
        ],
      ),
    );
  }

  Widget _buildPostResults(
      MoltSearchController controller, AuthProvider auth) {
    if (controller.postResults.isEmpty) {
      return Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(Icons.search_off_rounded,
                size: 48, color: AppTheme.textMuted.withValues(alpha: 0.4)),
            const SizedBox(height: 12),
            Text(
              'No posts found for "${controller.searchQuery.value}"',
              style: const TextStyle(color: AppTheme.textMuted, fontSize: 14),
              textAlign: TextAlign.center,
            ),
          ],
        ),
      );
    }

    return ListView.builder(
      padding: const EdgeInsets.only(top: 8, bottom: 20),
      itemCount: controller.postResults.length,
      itemBuilder: (context, index) {
        final post = controller.postResults[index];
        return PostCard(
          post: post,
          currentAgentId: auth.currentAgent.value?.agentId,
          onTap: () => Get.toNamed('/post/${post.id}', arguments: post),
        );
      },
    );
  }

  Widget _buildSubmoltResults(MoltSearchController controller) {
    if (controller.submoltResults.isEmpty) {
      return Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(Icons.search_off_rounded,
                size: 48, color: AppTheme.textMuted.withValues(alpha: 0.4)),
            const SizedBox(height: 12),
            Text(
              'No submolts found for "${controller.searchQuery.value}"',
              style: const TextStyle(color: AppTheme.textMuted, fontSize: 14),
              textAlign: TextAlign.center,
            ),
          ],
        ),
      );
    }

    return ListView.builder(
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
      itemCount: controller.submoltResults.length,
      itemBuilder: (context, index) {
        final submolt = controller.submoltResults[index];
        return _SubmoltCard(submolt: submolt);
      },
    );
  }
}

class _TypeChip extends StatelessWidget {
  final String label;
  final IconData icon;
  final bool isSelected;
  final VoidCallback onTap;

  const _TypeChip({
    required this.label,
    required this.icon,
    required this.isSelected,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 180),
        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
        decoration: BoxDecoration(
          color: isSelected
              ? AppTheme.primary.withValues(alpha: 0.15)
              : AppTheme.surfaceLight,
          borderRadius: BorderRadius.circular(20),
          border: Border.all(
            color: isSelected
                ? AppTheme.primary.withValues(alpha: 0.5)
                : AppTheme.divider,
          ),
        ),
        child: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(icon,
                size: 16,
                color:
                    isSelected ? AppTheme.primary : AppTheme.textMuted),
            const SizedBox(width: 6),
            Text(
              label,
              style: TextStyle(
                color: isSelected
                    ? AppTheme.primary
                    : AppTheme.textSecondary,
                fontWeight:
                    isSelected ? FontWeight.w600 : FontWeight.w400,
                fontSize: 13,
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _SubmoltCard extends StatelessWidget {
  final Submolt submolt;
  const _SubmoltCard({required this.submolt});

  @override
  Widget build(BuildContext context) {
    return InkWell(
      onTap: () => Get.toNamed('/submolt/${submolt.name}'),
      borderRadius: BorderRadius.circular(12),
      child: Container(
        margin: const EdgeInsets.only(bottom: 8),
        padding: const EdgeInsets.all(14),
        decoration: BoxDecoration(
          color: AppTheme.cardColor,
          borderRadius: BorderRadius.circular(12),
          border: Border.all(color: AppTheme.divider.withValues(alpha: 0.3)),
        ),
        child: Row(
          children: [
            CircleAvatar(
              radius: 22,
              backgroundColor: AppTheme.primary.withValues(alpha: 0.15),
              child: const Text('m/',
                  style: TextStyle(
                      color: AppTheme.primary,
                      fontWeight: FontWeight.w700,
                      fontSize: 12)),
            ),
            const SizedBox(width: 12),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    'm/${submolt.name}',
                    style: const TextStyle(
                      color: AppTheme.textPrimary,
                      fontWeight: FontWeight.w600,
                      fontSize: 15,
                    ),
                  ),
                  if (submolt.displayName != null &&
                      submolt.displayName!.isNotEmpty) ...[
                    Text(
                      submolt.displayName!,
                      style: const TextStyle(
                          color: AppTheme.textSecondary, fontSize: 12),
                    ),
                  ],
                  if (submolt.description != null &&
                      submolt.description!.isNotEmpty) ...[
                    const SizedBox(height: 4),
                    Text(
                      submolt.description!,
                      style: const TextStyle(
                          color: AppTheme.textMuted, fontSize: 12),
                      maxLines: 2,
                      overflow: TextOverflow.ellipsis,
                    ),
                  ],
                ],
              ),
            ),
            if (submolt.subscriberCount > 0)
              Column(
                crossAxisAlignment: CrossAxisAlignment.end,
                children: [
                  Text(
                    _formatNumber(submolt.subscriberCount),
                    style: const TextStyle(
                        color: AppTheme.primary,
                        fontWeight: FontWeight.w700,
                        fontSize: 14),
                  ),
                  const Text(
                    'members',
                    style:
                        TextStyle(color: AppTheme.textMuted, fontSize: 10),
                  ),
                ],
              ),
            const SizedBox(width: 4),
            const Icon(Icons.chevron_right_rounded,
                color: AppTheme.textMuted, size: 18),
          ],
        ),
      ),
    );
  }

  String _formatNumber(int n) {
    if (n >= 1000000) return '${(n / 1000000).toStringAsFixed(1)}M';
    if (n >= 1000) return '${(n / 1000).toStringAsFixed(1)}K';
    return n.toString();
  }
}
