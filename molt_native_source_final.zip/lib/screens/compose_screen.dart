import 'package:flutter/material.dart';
import 'package:get/get.dart';
import '../models/models.dart';
import '../services/api_service.dart';
import '../theme/app_theme.dart';

class ComposeController extends GetxController {
  final api = Get.find<ApiService>();

  final titleController = TextEditingController();
  final contentController = TextEditingController();
  final manualSubmoltController = TextEditingController();

  final submolts = <Submolt>[].obs;
  final selectedSubmolt = Rxn<String>();
  final isLoadingSubmolts = true.obs;
  final isSubmitting = false.obs;
  final showNewSubmoltForm = false.obs;
  final isCreatingSubmolt = false.obs;
  final useManualInput = false.obs;

  final newSubmoltNameController = TextEditingController();
  final newSubmoltDisplayController = TextEditingController();
  final newSubmoltDescController = TextEditingController();

  @override
  void onInit() {
    super.onInit();
    _loadSubmolts();
  }

  @override
  void onClose() {
    titleController.dispose();
    contentController.dispose();
    manualSubmoltController.dispose();
    newSubmoltNameController.dispose();
    newSubmoltDisplayController.dispose();
    newSubmoltDescController.dispose();
    super.onClose();
  }

  Future<void> _loadSubmolts() async {
    isLoadingSubmolts.value = true;
    try {
      final result = await api.getSubmolts(limit: 100);
      if (result.isNotEmpty) {
        submolts.assignAll(result);
        selectedSubmolt.value = result.first.name;
        useManualInput.value = false;
      } else {
        _useFallbackSubmolts();
      }
    } catch (_) {
      _useFallbackSubmolts();
    } finally {
      isLoadingSubmolts.value = false;
    }
  }

  void _useFallbackSubmolts() {
    submolts.assignAll([
      Submolt(name: 'general', displayName: 'General'),
      Submolt(name: 'introductions', displayName: 'Introductions'),
      Submolt(name: 'agents', displayName: 'Agents'),
      Submolt(name: 'builds', displayName: 'Builds'),
      Submolt(name: 'philosophy', displayName: 'Philosophy'),
    ]);
    selectedSubmolt.value = 'general';
  }

  String? get effectiveSubmolt {
    if (useManualInput.value) {
      final text = manualSubmoltController.text.trim().toLowerCase();
      return text.isEmpty ? null : text;
    }
    return selectedSubmolt.value;
  }

  Future<void> createNewSubmolt() async {
    final name = newSubmoltNameController.text.trim().toLowerCase().replaceAll(' ', '-');
    final display = newSubmoltDisplayController.text.trim();
    final desc = newSubmoltDescController.text.trim();

    if (name.isEmpty || display.isEmpty) {
      Get.snackbar('Error', 'Name and display name are required',
          backgroundColor: AppTheme.accent, colorText: Colors.white);
      return;
    }

    isCreatingSubmolt.value = true;
    try {
      final submolt = await api.createSubmolt(
        name: name,
        displayName: display,
        description: desc,
      );
      submolts.insert(0, submolt);
      selectedSubmolt.value = submolt.name;
      useManualInput.value = false;
      showNewSubmoltForm.value = false;
      newSubmoltNameController.clear();
      newSubmoltDisplayController.clear();
      newSubmoltDescController.clear();
      Get.snackbar('Created!', 'm/${submolt.name} is ready',
          backgroundColor: AppTheme.primary, colorText: Colors.black);
    } catch (e) {
      Get.snackbar('Error', e.toString().replaceFirst('Exception: ', ''),
          backgroundColor: AppTheme.accent, colorText: Colors.white);
    } finally {
      isCreatingSubmolt.value = false;
    }
  }

  Future<void> submitPost() async {
    final title = titleController.text.trim();
    final content = contentController.text.trim();
    final submolt = effectiveSubmolt;

    if (title.isEmpty) {
      Get.snackbar('Error', 'Title is required',
          backgroundColor: AppTheme.accent, colorText: Colors.white);
      return;
    }
    if (submolt == null || submolt.isEmpty) {
      Get.snackbar('Error', 'Please select or type a submolt name',
          backgroundColor: AppTheme.accent, colorText: Colors.white);
      return;
    }

    isSubmitting.value = true;
    try {
      await api.createPost(
        title: title,
        content: content,
        submolt: submolt,
      );
      Get.back();
      Get.snackbar('Posted!', 'Your post was published to m/$submolt',
          backgroundColor: AppTheme.primary, colorText: Colors.black);
    } catch (e) {
      final msg = e.toString().replaceFirst('Exception: ', '');
      Get.snackbar(
        'Post Failed',
        msg.contains('429') ? 'Rate limit reached. Agents can post once every 30 minutes.' : msg,
        backgroundColor: AppTheme.accent,
        colorText: Colors.white,
        duration: const Duration(seconds: 5),
      );
    } finally {
      isSubmitting.value = false;
    }
  }
}

class ComposeScreen extends StatelessWidget {
  const ComposeScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final controller = Get.put(ComposeController());

    return Scaffold(
      appBar: AppBar(
        title: const Text('New Post'),
        actions: [
          Obx(() => Padding(
                padding: const EdgeInsets.only(right: 12),
                child: ElevatedButton(
                  onPressed:
                      controller.isSubmitting.value ? null : controller.submitPost,
                  child: controller.isSubmitting.value
                      ? const SizedBox(
                          width: 20,
                          height: 20,
                          child: CircularProgressIndicator(
                              strokeWidth: 2, color: Colors.black),
                        )
                      : const Text('Publish'),
                ),
              )),
        ],
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // ── SUBMOLT SECTION ──────────────────────────────────
            const Text(
              'SUBMOLT',
              style: TextStyle(
                color: AppTheme.primary,
                fontSize: 11,
                fontWeight: FontWeight.w600,
                letterSpacing: 1.5,
              ),
            ),
            const SizedBox(height: 8),
            Obx(() {
              if (controller.isLoadingSubmolts.value) {
                return Container(
                  height: 52,
                  decoration: BoxDecoration(
                    color: AppTheme.surfaceLight,
                    borderRadius: BorderRadius.circular(12),
                  ),
                  child: const Center(
                    child: SizedBox(
                      width: 20,
                      height: 20,
                      child: CircularProgressIndicator(
                          strokeWidth: 2, color: AppTheme.primary),
                    ),
                  ),
                );
              }

              return Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  // Toggle between dropdown and manual input
                  Row(
                    children: [
                      Expanded(
                        child: Obx(() => ChoiceChip(
                              label: const Text('Choose from list'),
                              selected: !controller.useManualInput.value,
                              onSelected: (_) =>
                                  controller.useManualInput.value = false,
                              selectedColor:
                                  AppTheme.primary.withValues(alpha: 0.2),
                              labelStyle: TextStyle(
                                color: !controller.useManualInput.value
                                    ? AppTheme.primary
                                    : AppTheme.textMuted,
                                fontSize: 12,
                              ),
                            )),
                      ),
                      const SizedBox(width: 8),
                      Expanded(
                        child: Obx(() => ChoiceChip(
                              label: const Text('Type manually'),
                              selected: controller.useManualInput.value,
                              onSelected: (_) =>
                                  controller.useManualInput.value = true,
                              selectedColor:
                                  AppTheme.primary.withValues(alpha: 0.2),
                              labelStyle: TextStyle(
                                color: controller.useManualInput.value
                                    ? AppTheme.primary
                                    : AppTheme.textMuted,
                                fontSize: 12,
                              ),
                            )),
                      ),
                    ],
                  ),
                  const SizedBox(height: 8),

                  // Dropdown or manual text input
                  Obx(() => controller.useManualInput.value
                      ? TextField(
                          controller: controller.manualSubmoltController,
                          style: const TextStyle(
                              color: AppTheme.textPrimary, fontSize: 15),
                          decoration: InputDecoration(
                            hintText: 'e.g. general, agents, builds...',
                            prefixText: 'm/',
                            prefixStyle: const TextStyle(
                                color: AppTheme.primary,
                                fontWeight: FontWeight.w600),
                            filled: true,
                            fillColor: AppTheme.surfaceLight,
                            border: OutlineInputBorder(
                              borderRadius: BorderRadius.circular(12),
                              borderSide:
                                  BorderSide(color: AppTheme.primary.withValues(alpha: 0.4)),
                            ),
                            focusedBorder: OutlineInputBorder(
                              borderRadius: BorderRadius.circular(12),
                              borderSide: const BorderSide(
                                  color: AppTheme.primary, width: 1.5),
                            ),
                          ),
                        )
                      : _buildDropdown(controller)),

                  const SizedBox(height: 8),

                  // Create new submolt option
                  Obx(() => controller.showNewSubmoltForm.value
                      ? _buildNewSubmoltForm(controller)
                      : Align(
                          alignment: Alignment.centerLeft,
                          child: TextButton.icon(
                            onPressed: () =>
                                controller.showNewSubmoltForm.value = true,
                            icon: const Icon(Icons.add_circle_outline_rounded,
                                size: 18),
                            label: const Text('Create New Submolt'),
                            style: TextButton.styleFrom(
                              foregroundColor: AppTheme.primary,
                            ),
                          ),
                        )),
                ],
              );
            }),

            const SizedBox(height: 20),

            // ── TITLE ─────────────────────────────────────────────
            const Text(
              'TITLE',
              style: TextStyle(
                color: AppTheme.primary,
                fontSize: 11,
                fontWeight: FontWeight.w600,
                letterSpacing: 1.5,
              ),
            ),
            const SizedBox(height: 8),
            TextField(
              controller: controller.titleController,
              style: const TextStyle(
                  color: AppTheme.textPrimary,
                  fontSize: 18,
                  fontWeight: FontWeight.w600),
              maxLines: 2,
              decoration: const InputDecoration(
                hintText: 'An interesting title...',
              ),
            ),

            const SizedBox(height: 20),

            // ── CONTENT ───────────────────────────────────────────
            const Text(
              'CONTENT',
              style: TextStyle(
                color: AppTheme.primary,
                fontSize: 11,
                fontWeight: FontWeight.w600,
                letterSpacing: 1.5,
              ),
            ),
            const SizedBox(height: 8),
            TextField(
              controller: controller.contentController,
              style: const TextStyle(
                  color: AppTheme.textPrimary, fontSize: 15, height: 1.6),
              maxLines: 15,
              minLines: 8,
              decoration: const InputDecoration(
                hintText: 'Write your post here... (Markdown supported)',
                alignLabelWithHint: true,
              ),
            ),

            const SizedBox(height: 12),
            Container(
              padding: const EdgeInsets.all(10),
              decoration: BoxDecoration(
                color: AppTheme.surfaceLight.withValues(alpha: 0.5),
                borderRadius: BorderRadius.circular(8),
              ),
              child: const Row(
                children: [
                  Icon(Icons.info_outline_rounded,
                      size: 16, color: AppTheme.textMuted),
                  SizedBox(width: 8),
                  Text(
                    'Markdown supported · Rate limit: 1 post / 30 min',
                    style: TextStyle(color: AppTheme.textMuted, fontSize: 12),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 40),
          ],
        ),
      ),
    );
  }

  Widget _buildDropdown(ComposeController controller) {
    return Obx(() {
      final submolts = controller.submolts;
      final selected = controller.selectedSubmolt.value;

      // Ensure selected value exists in list
      final validSelected = submolts.any((s) => s.name == selected)
          ? selected
          : (submolts.isNotEmpty ? submolts.first.name : null);

      if (submolts.isEmpty) {
        return Container(
          padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 14),
          decoration: BoxDecoration(
            color: AppTheme.surfaceLight,
            borderRadius: BorderRadius.circular(12),
            border: Border.all(color: AppTheme.divider),
          ),
          child: const Text(
            'No submolts available — use "Type manually" above',
            style: TextStyle(color: AppTheme.textMuted, fontSize: 13),
          ),
        );
      }

      return Container(
        padding: const EdgeInsets.symmetric(horizontal: 12),
        decoration: BoxDecoration(
          color: AppTheme.surfaceLight,
          borderRadius: BorderRadius.circular(12),
          border: Border.all(color: AppTheme.divider),
        ),
        child: DropdownButtonHideUnderline(
          child: DropdownButton<String>(
            value: validSelected,
            isExpanded: true,
            dropdownColor: AppTheme.surface,
            style: const TextStyle(color: AppTheme.textPrimary, fontSize: 14),
            icon: const Icon(Icons.expand_more_rounded, color: AppTheme.primary),
            items: submolts.map((s) {
              return DropdownMenuItem(
                value: s.name,
                child: Text('m/${s.name}'),
              );
            }).toList(),
            onChanged: (val) {
              controller.selectedSubmolt.value = val;
            },
          ),
        ),
      );
    });
  }

  Widget _buildNewSubmoltForm(ComposeController controller) {
    return Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: AppTheme.surfaceLight,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: AppTheme.primary.withValues(alpha: 0.3)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              const Text(
                'Create New Submolt',
                style: TextStyle(
                    color: AppTheme.primary,
                    fontWeight: FontWeight.w600,
                    fontSize: 14),
              ),
              IconButton(
                icon: const Icon(Icons.close_rounded,
                    size: 18, color: AppTheme.textMuted),
                onPressed: () => controller.showNewSubmoltForm.value = false,
                padding: EdgeInsets.zero,
                constraints: const BoxConstraints(),
              ),
            ],
          ),
          const SizedBox(height: 10),
          TextField(
            controller: controller.newSubmoltNameController,
            style: const TextStyle(color: AppTheme.textPrimary, fontSize: 14),
            decoration: const InputDecoration(
              hintText: 'Name (lowercase, hyphens ok)',
              prefixText: 'm/',
              prefixStyle: TextStyle(color: AppTheme.primary),
              isDense: true,
            ),
          ),
          const SizedBox(height: 8),
          TextField(
            controller: controller.newSubmoltDisplayController,
            style: const TextStyle(color: AppTheme.textPrimary, fontSize: 14),
            decoration: const InputDecoration(
              hintText: 'Display Name',
              isDense: true,
            ),
          ),
          const SizedBox(height: 8),
          TextField(
            controller: controller.newSubmoltDescController,
            style: const TextStyle(color: AppTheme.textPrimary, fontSize: 14),
            maxLines: 2,
            decoration: const InputDecoration(
              hintText: 'Description (optional)',
              isDense: true,
            ),
          ),
          const SizedBox(height: 12),
          Obx(() => SizedBox(
                width: double.infinity,
                child: ElevatedButton(
                  onPressed: controller.isCreatingSubmolt.value
                      ? null
                      : controller.createNewSubmolt,
                  child: controller.isCreatingSubmolt.value
                      ? const SizedBox(
                          width: 20,
                          height: 20,
                          child: CircularProgressIndicator(
                              strokeWidth: 2, color: Colors.black),
                        )
                      : const Text('Create Submolt'),
                ),
              )),
        ],
      ),
    );
  }
}
