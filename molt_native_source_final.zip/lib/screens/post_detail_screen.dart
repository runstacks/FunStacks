import 'package:flutter/material.dart';
import 'package:flutter_markdown/flutter_markdown.dart';
import 'package:get/get.dart';
import 'package:share_plus/share_plus.dart';
import 'package:timeago/timeago.dart' as timeago;
import '../models/models.dart';
import '../services/api_service.dart';
import '../providers/auth_provider.dart';
import '../theme/app_theme.dart';
import '../widgets/comment_tree.dart';
import '../widgets/shimmer_widgets.dart';

class PostDetailController extends GetxController {
  final api = Get.find<ApiService>();
  final auth = Get.find<AuthProvider>();

  final post = Rxn<Post>();
  final comments = <Comment>[].obs;
  final isLoadingComments = true.obs;
  final isSubmittingComment = false.obs;
  final replyingTo = Rxn<Comment>();
  final commentController = TextEditingController();
  final commentFocusNode = FocusNode();
  final errorComments = ''.obs;

  // Reactive vote state for the post
  final voteState = 0.obs;
  final displayScore = 0.obs;

  String? postId;

  @override
  void onInit() {
    super.onInit();
    if (Get.arguments is Post) {
      post.value = Get.arguments as Post;
      postId = post.value!.id;
      displayScore.value = post.value!.score;
    } else {
      postId = Get.parameters['id'];
    }
    if (postId != null && postId!.isNotEmpty) {
      loadComments();
      if (post.value == null) loadPost();
    }
  }

  @override
  void onClose() {
    commentController.dispose();
    commentFocusNode.dispose();
    super.onClose();
  }

  Future<void> loadPost() async {
    try {
      post.value = await api.getPost(postId!);
      // Sync score on load only if not yet voted
      if (voteState.value == 0) {
        displayScore.value = post.value!.score;
      }
    } catch (_) {}
  }

  Future<void> loadComments() async {
    isLoadingComments.value = true;
    errorComments.value = '';
    try {
      final result = await api.getComments(postId!, sort: 'best');
      comments.assignAll(result);
    } catch (e) {
      errorComments.value = e.toString().replaceFirst('Exception: ', '');
    } finally {
      isLoadingComments.value = false;
    }
  }

  void setReplyTarget(Comment? comment) {
    replyingTo.value = comment;
    if (comment != null) {
      commentFocusNode.requestFocus();
    }
  }

  Future<void> submitComment() async {
    final text = commentController.text.trim();
    if (text.isEmpty || postId == null) return;

    isSubmittingComment.value = true;
    try {
      if (replyingTo.value != null) {
        await api.replyToComment(replyingTo.value!.id, text);
      } else {
        await api.createComment(postId!, text);
      }
      commentController.clear();
      replyingTo.value = null;
      commentFocusNode.unfocus();
      await loadComments();
    } catch (e) {
      Get.snackbar(
        'Comment Failed',
        e.toString().replaceFirst('Exception: ', ''),
        backgroundColor: AppTheme.accent,
        colorText: Colors.white,
      );
    } finally {
      isSubmittingComment.value = false;
    }
  }

  Future<void> deletePost() async {
    try {
      await api.deletePost(postId!);
      Get.back();
      Get.snackbar('Deleted', 'Post removed',
          backgroundColor: AppTheme.primary, colorText: Colors.black);
    } catch (e) {
      Get.snackbar('Error', e.toString().replaceFirst('Exception: ', ''),
          backgroundColor: AppTheme.accent, colorText: Colors.white);
    }
  }

  Future<void> handleVote(int direction) async {
    // Optimistic local update
    final prev = voteState.value;
    if (prev == direction) {
      displayScore.value -= direction;
      voteState.value = 0;
    } else {
      displayScore.value -= prev;
      displayScore.value += direction;
      voteState.value = direction;
    }
    try {
      if (direction == 1) {
        await api.upvotePost(postId!);
      } else {
        await api.downvotePost(postId!);
      }
    } catch (_) {
      // Revert on failure
      voteState.value = prev;
      if (post.value != null) displayScore.value = post.value!.score;
    }
  }

  Future<void> handleCommentVote(Comment comment, int direction) async {
    try {
      if (direction == 1) {
        await api.upvoteComment(comment.id);
      } else {
        await api.downvoteComment(comment.id);
      }
    } catch (_) {}
  }

  int get totalCommentCount {
    int count = 0;
    void countAll(List<Comment> list) {
      for (final c in list) {
        count++;
        if (c.replies.isNotEmpty) countAll(c.replies);
      }
    }
    countAll(comments);
    return count;
  }
}

class PostDetailScreen extends StatelessWidget {
  const PostDetailScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final controller = Get.put(PostDetailController());
    final auth = Get.find<AuthProvider>();

    return Scaffold(
      appBar: AppBar(
        title: const Text('Post'),
        actions: [
          Obx(() {
            final p = controller.post.value;
            if (p != null &&
                auth.currentAgent.value != null &&
                p.author.agentId == auth.currentAgent.value!.agentId) {
              return IconButton(
                icon: const Icon(Icons.delete_outline_rounded,
                    color: AppTheme.accent),
                onPressed: () => _showDeleteDialog(context, controller),
              );
            }
            return const SizedBox.shrink();
          }),
          IconButton(
            icon: const Icon(Icons.share_outlined),
            onPressed: () {
              final p = controller.post.value;
              if (p != null) {
                Share.share(
                  '${p.title}\nhttps://www.moltbook.com/post/${p.id}',
                );
              }
            },
          ),
        ],
      ),
      body: Column(
        children: [
          Expanded(
            child: Obx(() {
              final p = controller.post.value;
              if (p == null) {
                return const Center(
                  child: CircularProgressIndicator(color: AppTheme.primary),
                );
              }

              return RefreshIndicator(
                onRefresh: () async {
                  await Future.wait([
                    controller.loadPost(),
                    controller.loadComments(),
                  ]);
                },
                color: AppTheme.primary,
                backgroundColor: AppTheme.surface,
                child: CustomScrollView(
                  physics: const AlwaysScrollableScrollPhysics(),
                  slivers: [
                    // Post header
                    SliverToBoxAdapter(
                      child: _buildPostHeader(context, p, controller),
                    ),

                    const SliverToBoxAdapter(
                        child: Divider(height: 1, thickness: 1)),

                    // Comments header
                    SliverToBoxAdapter(
                      child: Padding(
                        padding: const EdgeInsets.fromLTRB(16, 12, 16, 4),
                        child: Obx(() => Text(
                              'Comments (${controller.totalCommentCount})',
                              style: const TextStyle(
                                color: AppTheme.textPrimary,
                                fontWeight: FontWeight.w600,
                                fontSize: 16,
                              ),
                            )),
                      ),
                    ),

                    // Comments content
                    SliverToBoxAdapter(
                      child: Obx(() {
                        if (controller.isLoadingComments.value) {
                          return Column(
                            children: List.generate(
                                5, (_) => const CommentSkeleton()),
                          );
                        }

                        if (controller.errorComments.value.isNotEmpty) {
                          return Padding(
                            padding: const EdgeInsets.all(24),
                            child: Column(
                              children: [
                                const Icon(Icons.error_outline_rounded,
                                    color: AppTheme.accent, size: 40),
                                const SizedBox(height: 12),
                                Text(
                                  controller.errorComments.value,
                                  style: const TextStyle(
                                      color: AppTheme.textSecondary),
                                  textAlign: TextAlign.center,
                                ),
                                const SizedBox(height: 12),
                                ElevatedButton.icon(
                                  onPressed: controller.loadComments,
                                  icon: const Icon(Icons.refresh_rounded),
                                  label: const Text('Retry'),
                                ),
                              ],
                            ),
                          );
                        }

                        if (controller.comments.isEmpty) {
                          return const Padding(
                            padding: EdgeInsets.all(32),
                            child: Center(
                              child: Column(
                                children: [
                                  Icon(Icons.chat_bubble_outline_rounded,
                                      size: 40,
                                      color: AppTheme.textMuted),
                                  SizedBox(height: 12),
                                  Text(
                                    'No comments yet. Be the first!',
                                    style:
                                        TextStyle(color: AppTheme.textMuted),
                                  ),
                                ],
                              ),
                            ),
                          );
                        }

                        return Padding(
                          padding: const EdgeInsets.symmetric(
                              horizontal: 4, vertical: 4),
                          child: CommentTree(
                            comments: controller.comments,
                            currentAgentId:
                                auth.currentAgent.value?.agentId,
                            onReply: (comment) =>
                                controller.setReplyTarget(comment),
                            onVote: (comment, dir) =>
                                controller.handleCommentVote(comment, dir),
                            onDelete: (_) {},
                          ),
                        );
                      }),
                    ),

                    const SliverToBoxAdapter(child: SizedBox(height: 80)),
                  ],
                ),
              );
            }),
          ),

          // Comment input bar
          _buildCommentInput(controller),
        ],
      ),
    );
  }

  Widget _buildPostHeader(
      BuildContext context, Post post, PostDetailController controller) {
    final createdAt = DateTime.tryParse(post.createdAt);
    final timeAgo = createdAt != null ? timeago.format(createdAt) : '';

    return Padding(
      padding: const EdgeInsets.all(16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // Submolt label
          GestureDetector(
            onTap: () {},
            child: Text(
              post.submolt.startsWith('m/')
                  ? post.submolt
                  : 'm/${post.submolt}',
              style: const TextStyle(
                color: AppTheme.primary,
                fontSize: 12,
                fontWeight: FontWeight.w600,
              ),
            ),
          ),
          const SizedBox(height: 6),

          // Title
          Text(
            post.title,
            style: const TextStyle(
              color: AppTheme.textPrimary,
              fontSize: 20,
              fontWeight: FontWeight.w700,
              height: 1.3,
            ),
          ),

          const SizedBox(height: 10),

          // Author row
          Row(
            children: [
              _buildAvatar(post.author),
              const SizedBox(width: 10),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      'u/${post.author.name}',
                      style: const TextStyle(
                        color: AppTheme.textPrimary,
                        fontWeight: FontWeight.w600,
                        fontSize: 13,
                      ),
                    ),
                    if (timeAgo.isNotEmpty)
                      Text(
                        timeAgo,
                        style: const TextStyle(
                            color: AppTheme.textMuted, fontSize: 11),
                      ),
                  ],
                ),
              ),
            ],
          ),

          // Full content (Markdown)
          if (post.content != null && post.content!.isNotEmpty) ...[
            const SizedBox(height: 14),
            MarkdownBody(
              data: post.content!,
              selectable: true,
              styleSheet: MarkdownStyleSheet(
                p: const TextStyle(
                  color: AppTheme.textSecondary,
                  fontSize: 15,
                  height: 1.6,
                ),
                h1: const TextStyle(
                    color: AppTheme.textPrimary,
                    fontSize: 22,
                    fontWeight: FontWeight.w700),
                h2: const TextStyle(
                    color: AppTheme.textPrimary,
                    fontSize: 19,
                    fontWeight: FontWeight.w600),
                h3: const TextStyle(
                    color: AppTheme.textPrimary,
                    fontSize: 17,
                    fontWeight: FontWeight.w600),
                code: TextStyle(
                  color: AppTheme.primary.withValues(alpha: 0.9),
                  backgroundColor: AppTheme.surfaceLight,
                  fontSize: 13,
                ),
                codeblockDecoration: BoxDecoration(
                  color: AppTheme.surfaceLight,
                  borderRadius: BorderRadius.circular(8),
                ),
                strong: const TextStyle(color: AppTheme.textPrimary),
                em: const TextStyle(color: AppTheme.textSecondary),
                blockquoteDecoration: BoxDecoration(
                  border: Border(
                    left: BorderSide(
                        color: AppTheme.primary.withValues(alpha: 0.5),
                        width: 3),
                  ),
                ),
                listBullet:
                    const TextStyle(color: AppTheme.primary),
              ),
            ),
          ],

          const SizedBox(height: 16),

          // Score row + vote buttons
          Obx(() => Row(
            children: [
              // Upvote
              InkWell(
                onTap: () => controller.handleVote(1),
                borderRadius: BorderRadius.circular(6),
                child: Padding(
                  padding:
                      const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                  child: Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Icon(Icons.arrow_upward_rounded,
                          size: 18,
                          color: controller.voteState.value == 1
                              ? AppTheme.upvote
                              : AppTheme.upvote.withValues(alpha: 0.45)),
                      const SizedBox(width: 4),
                      Text(
                        '${controller.displayScore.value}',
                        style: TextStyle(
                            color: controller.voteState.value == 1
                                ? AppTheme.upvote
                                : controller.voteState.value == -1
                                    ? AppTheme.downvote
                                    : AppTheme.textSecondary,
                            fontSize: 13,
                            fontWeight: FontWeight.w600),
                      ),
                    ],
                  ),
                ),
              ),
              // Downvote
              InkWell(
                onTap: () => controller.handleVote(-1),
                borderRadius: BorderRadius.circular(6),
                child: Padding(
                  padding:
                      const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                  child: Icon(Icons.arrow_downward_rounded,
                      size: 18,
                      color: controller.voteState.value == -1
                          ? AppTheme.downvote
                          : AppTheme.downvote.withValues(alpha: 0.45)),
                ),
              ),
              const SizedBox(width: 8),
              Icon(Icons.chat_bubble_outline_rounded,
                  size: 16,
                  color: AppTheme.textMuted.withValues(alpha: 0.7)),
              const SizedBox(width: 4),
              Text(
                '${post.commentCount} comments',
                style: const TextStyle(
                    color: AppTheme.textSecondary, fontSize: 12),
              ),
            ],
          )),
        ],
      ),
    );
  }

  Widget _buildAvatar(PostAuthor author) {
    if (author.avatarUrl != null && author.avatarUrl!.isNotEmpty) {
      return CircleAvatar(
        radius: 18,
        backgroundImage: NetworkImage(author.avatarUrl!),
        backgroundColor: AppTheme.surfaceLight,
      );
    }
    return CircleAvatar(
      radius: 18,
      backgroundColor: AppTheme.primary.withValues(alpha: 0.2),
      child: Text(
        author.name.isNotEmpty ? author.name[0].toUpperCase() : '?',
        style: const TextStyle(
          color: AppTheme.primary,
          fontWeight: FontWeight.w700,
          fontSize: 16,
        ),
      ),
    );
  }

  Widget _buildCommentInput(PostDetailController controller) {
    return Container(
      decoration: BoxDecoration(
        color: AppTheme.surface,
        border: Border(
          top: BorderSide(color: AppTheme.divider.withValues(alpha: 0.5)),
        ),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withValues(alpha: 0.1),
            blurRadius: 8,
            offset: const Offset(0, -2),
          ),
        ],
      ),
      padding: const EdgeInsets.fromLTRB(12, 8, 12, 8),
      child: SafeArea(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            // Reply indicator
            Obx(() {
              final replyTarget = controller.replyingTo.value;
              if (replyTarget != null) {
                return Container(
                  padding:
                      const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                  margin: const EdgeInsets.only(bottom: 6),
                  decoration: BoxDecoration(
                    color: AppTheme.primary.withValues(alpha: 0.1),
                    borderRadius: BorderRadius.circular(8),
                  ),
                  child: Row(
                    children: [
                      const Icon(Icons.reply_rounded,
                          size: 14, color: AppTheme.primary),
                      const SizedBox(width: 6),
                      Expanded(
                        child: Text(
                          'Replying to u/${replyTarget.author.name}',
                          style: const TextStyle(
                              color: AppTheme.textSecondary, fontSize: 12),
                          overflow: TextOverflow.ellipsis,
                        ),
                      ),
                      GestureDetector(
                        onTap: () => controller.setReplyTarget(null),
                        child: const Icon(Icons.close_rounded,
                            size: 16, color: AppTheme.textMuted),
                      ),
                    ],
                  ),
                );
              }
              return const SizedBox.shrink();
            }),

            Row(
              crossAxisAlignment: CrossAxisAlignment.end,
              children: [
                Expanded(
                  child: TextField(
                    controller: controller.commentController,
                    focusNode: controller.commentFocusNode,
                    style: const TextStyle(
                        color: AppTheme.textPrimary, fontSize: 14),
                    maxLines: 4,
                    minLines: 1,
                    decoration: InputDecoration(
                      hintText: 'Write a comment...',
                      filled: true,
                      fillColor: AppTheme.surfaceLight,
                      contentPadding: const EdgeInsets.symmetric(
                          horizontal: 14, vertical: 10),
                      border: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(24),
                        borderSide: BorderSide.none,
                      ),
                    ),
                  ),
                ),
                const SizedBox(width: 8),
                Obx(() => Material(
                      color: AppTheme.primary,
                      borderRadius: BorderRadius.circular(24),
                      child: InkWell(
                        onTap: controller.isSubmittingComment.value
                            ? null
                            : controller.submitComment,
                        borderRadius: BorderRadius.circular(24),
                        child: Padding(
                          padding: const EdgeInsets.all(10),
                          child: controller.isSubmittingComment.value
                              ? const SizedBox(
                                  width: 20,
                                  height: 20,
                                  child: CircularProgressIndicator(
                                      strokeWidth: 2,
                                      color: Colors.black),
                                )
                              : const Icon(Icons.send_rounded,
                                  color: Colors.black, size: 20),
                        ),
                      ),
                    )),
              ],
            ),
          ],
        ),
      ),
    );
  }

  void _showDeleteDialog(
      BuildContext context, PostDetailController controller) {
    showDialog(
      context: context,
      builder: (ctx) => AlertDialog(
        backgroundColor: AppTheme.surface,
        title: const Text('Delete Post',
            style: TextStyle(color: AppTheme.textPrimary)),
        content: const Text(
          'Are you sure? This cannot be undone.',
          style: TextStyle(color: AppTheme.textSecondary),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(ctx),
            child: const Text('Cancel',
                style: TextStyle(color: AppTheme.textMuted)),
          ),
          TextButton(
            onPressed: () {
              Navigator.pop(ctx);
              controller.deletePost();
            },
            child: const Text('Delete',
                style: TextStyle(color: AppTheme.accent)),
          ),
        ],
      ),
    );
  }
}


