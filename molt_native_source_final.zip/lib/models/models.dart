// ============================================================
// Moltbook Data Models — Fixed for real API structure
// ============================================================

class Agent {
  final String agentId;
  final String name;
  final String? bio;
  final String? avatarUrl;
  final int karma;
  final int postCount;
  final int commentCount;
  final int followerCount;
  final int followingCount;
  final String createdAt;
  final bool verified;
  final AgentOwner? owner;
  final String? description;
  final String? apiKey;

  Agent({
    required this.agentId,
    required this.name,
    this.bio,
    this.avatarUrl,
    this.karma = 0,
    this.postCount = 0,
    this.commentCount = 0,
    this.followerCount = 0,
    this.followingCount = 0,
    this.createdAt = '',
    this.verified = false,
    this.owner,
    this.description,
    this.apiKey,
  });

  factory Agent.fromJson(Map<String, dynamic> json) {
    // Handle both nested "agent" key and flat response
    final data = json.containsKey('agent') ? json['agent'] as Map<String, dynamic> : json;
    return Agent(
      // Real API uses "id" not "agent_id"
      agentId: data['id']?.toString() ?? data['agent_id']?.toString() ?? '',
      name: data['name']?.toString() ?? 'Unknown',
      bio: data['description']?.toString() ?? data['bio']?.toString(),
      // Real API uses "avatarUrl" (camelCase)
      avatarUrl: data['avatarUrl']?.toString() ?? data['avatar_url']?.toString() ?? data['avatar']?.toString(),
      karma: _parseInt(data['karma']),
      postCount: _parseInt(data['post_count'] ?? data['stats']?['posts']),
      commentCount: _parseInt(data['comment_count'] ?? data['stats']?['comments']),
      // Real API uses "followerCount" (camelCase)
      followerCount: _parseInt(data['followerCount'] ?? data['follower_count']),
      followingCount: _parseInt(data['followingCount'] ?? data['following_count']),
      // Real API uses "createdAt" (camelCase)
      createdAt: data['createdAt']?.toString() ?? data['created_at']?.toString() ?? '',
      // Real API uses "isClaimed" for verified status
      verified: data['isClaimed'] == true || data['verified'] == true || data['is_claimed'] == true,
      owner: data['owner'] != null ? AgentOwner.fromJson(data['owner']) : null,
      description: data['description']?.toString(),
      apiKey: data['api_key']?.toString(),
    );
  }

  static int _parseInt(dynamic value) {
    if (value == null) return 0;
    if (value is int) return value;
    if (value is double) return value.toInt();
    return int.tryParse(value.toString()) ?? 0;
  }
}

class AgentOwner {
  final String? displayName;
  final String? xHandle;
  final bool verified;

  AgentOwner({this.displayName, this.xHandle, this.verified = false});

  factory AgentOwner.fromJson(Map<String, dynamic> json) {
    return AgentOwner(
      displayName: json['display_name']?.toString() ?? json['x_name']?.toString(),
      xHandle: json['x_handle']?.toString(),
      verified: json['verified'] == true || json['x_verified'] == true,
    );
  }
}

class Post {
  final String id;
  final String title;
  final String? content;
  final String type;
  final String? url;
  final String submolt;
  final String? submoltDisplayName;
  final PostAuthor author;
  final int score;
  final int upvotes;
  final int downvotes;
  final double? upvoteRatio;
  final int commentCount;
  final String createdAt;
  final String? editedAt;
  final bool pinned;
  final bool locked;

  Post({
    required this.id,
    required this.title,
    this.content,
    this.type = 'text',
    this.url,
    required this.submolt,
    this.submoltDisplayName,
    required this.author,
    this.score = 0,
    this.upvotes = 0,
    this.downvotes = 0,
    this.upvoteRatio,
    this.commentCount = 0,
    this.createdAt = '',
    this.editedAt,
    this.pinned = false,
    this.locked = false,
  });

  factory Post.fromJson(Map<String, dynamic> json) {
    // Extract submolt name — real API returns submolt as an object {id, name, display_name}
    String submoltName = 'general';
    String? submoltDisplay;
    final submoltField = json['submolt'];
    if (submoltField is Map) {
      submoltName = submoltField['name']?.toString() ?? 'general';
      submoltDisplay = submoltField['display_name']?.toString();
    } else if (submoltField is String) {
      submoltName = submoltField;
    }

    // Strip HTML mark tags from search snippet content
    String? content = json['content']?.toString();
    if (content != null) {
      content = content.replaceAll('<mark>', '').replaceAll('</mark>', '');
    }

    return Post(
      id: json['id']?.toString() ?? json['post_id']?.toString() ?? '',
      title: json['title']?.toString() ?? 'Untitled',
      content: content,
      type: json['type']?.toString() ?? 'text',
      url: json['url']?.toString(),
      submolt: submoltName,
      submoltDisplayName: submoltDisplay,
      author: json['author'] != null
          ? PostAuthor.fromJson(json['author'] as Map<String, dynamic>)
          : PostAuthor(agentId: '', name: 'Unknown'),
      score: Agent._parseInt(json['score'] ?? json['upvotes']),
      upvotes: Agent._parseInt(json['upvotes']),
      downvotes: Agent._parseInt(json['downvotes']),
      upvoteRatio: (json['upvote_ratio'] as num?)?.toDouble(),
      commentCount: Agent._parseInt(json['comment_count'] ?? json['comments_count']),
      // Real API uses "created_at" (snake_case)
      createdAt: json['created_at']?.toString() ?? '',
      editedAt: json['edited_at']?.toString() ?? json['updatedAt']?.toString(),
      pinned: json['pinned'] == true || json['is_pinned'] == true,
      locked: json['locked'] == true || json['is_locked'] == true,
    );
  }
}

class PostAuthor {
  final String agentId;
  final String name;
  final String? avatarUrl;
  final int karma;

  PostAuthor({
    required this.agentId,
    required this.name,
    this.avatarUrl,
    this.karma = 0,
  });

  factory PostAuthor.fromJson(Map<String, dynamic> json) {
    return PostAuthor(
      // Real API uses "id" not "agent_id"
      agentId: json['id']?.toString() ?? json['agent_id']?.toString() ?? '',
      name: json['name']?.toString() ?? 'Unknown',
      // Real API uses "avatarUrl" (camelCase)
      avatarUrl: json['avatarUrl']?.toString() ?? json['avatar_url']?.toString() ?? json['avatar']?.toString(),
      karma: Agent._parseInt(json['karma']),
    );
  }
}

class Comment {
  final String id;
  final String content;
  final CommentAuthor author;
  final int score;
  final int upvotes;
  final int downvotes;
  final String createdAt;
  final String? parentId;
  final int depth;
  final int replyCount;
  final List<Comment> replies;
  final bool isDeleted;

  Comment({
    required this.id,
    required this.content,
    required this.author,
    this.score = 0,
    this.upvotes = 0,
    this.downvotes = 0,
    this.createdAt = '',
    this.parentId,
    this.depth = 0,
    this.replyCount = 0,
    this.replies = const [],
    this.isDeleted = false,
  });

  factory Comment.fromJson(Map<String, dynamic> json) {
    return Comment(
      id: json['id']?.toString() ?? '',
      content: json['content']?.toString() ?? '',
      author: json['author'] != null
          ? CommentAuthor.fromJson(json['author'] as Map<String, dynamic>)
          : CommentAuthor(agentId: '', name: 'Unknown'),
      score: Agent._parseInt(json['score']),
      upvotes: Agent._parseInt(json['upvotes']),
      downvotes: Agent._parseInt(json['downvotes']),
      createdAt: json['created_at']?.toString() ?? '',
      parentId: json['parent_id']?.toString(),
      depth: Agent._parseInt(json['depth']),
      replyCount: Agent._parseInt(json['reply_count']),
      isDeleted: json['is_deleted'] == true,
      replies: (json['replies'] as List<dynamic>?)
              ?.map((r) => Comment.fromJson(r as Map<String, dynamic>))
              .toList() ??
          [],
    );
  }
}

class CommentAuthor {
  final String agentId;
  final String name;
  final String? avatarUrl;
  final int karma;

  CommentAuthor({
    required this.agentId,
    required this.name,
    this.avatarUrl,
    this.karma = 0,
  });

  factory CommentAuthor.fromJson(Map<String, dynamic> json) {
    return CommentAuthor(
      agentId: json['id']?.toString() ?? json['agent_id']?.toString() ?? '',
      name: json['name']?.toString() ?? 'Unknown',
      // Real API uses "avatarUrl" (camelCase)
      avatarUrl: json['avatarUrl']?.toString() ?? json['avatar_url']?.toString() ?? json['avatar']?.toString(),
      karma: Agent._parseInt(json['karma']),
    );
  }
}

class Submolt {
  final String id;
  final String name;
  final String? displayName;
  final String? description;
  final int subscriberCount;
  final int postCount;
  final String? createdAt;
  final bool isNsfw;
  final bool isPrivate;

  Submolt({
    this.id = '',
    required this.name,
    this.displayName,
    this.description,
    this.subscriberCount = 0,
    this.postCount = 0,
    this.createdAt,
    this.isNsfw = false,
    this.isPrivate = false,
  });

  factory Submolt.fromJson(Map<String, dynamic> json) {
    // Handle both full submolt objects and search result submolt references
    final submoltData = json.containsKey('submolt') && json['submolt'] is Map
        ? json['submolt'] as Map<String, dynamic>
        : json;

    return Submolt(
      id: submoltData['id']?.toString() ?? '',
      name: submoltData['name']?.toString() ?? '',
      displayName: submoltData['display_name']?.toString(),
      description: submoltData['description']?.toString() ?? json['content']?.toString(),
      subscriberCount: Agent._parseInt(submoltData['subscriber_count'] ?? submoltData['members']),
      postCount: Agent._parseInt(submoltData['post_count']),
      createdAt: submoltData['created_at']?.toString(),
      isNsfw: submoltData['is_nsfw'] == true,
      isPrivate: submoltData['is_private'] == true,
    );
  }
}

class PaginatedResponse<T> {
  final List<T> data;
  final int total;
  final int offset;
  final int limit;
  final bool hasMore;
  final String? nextCursor;

  PaginatedResponse({
    required this.data,
    this.total = 0,
    this.offset = 0,
    this.limit = 25,
    this.hasMore = false,
    this.nextCursor,
  });
}
