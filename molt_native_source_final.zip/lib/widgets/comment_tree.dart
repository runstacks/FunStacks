import 'package:flutter/material.dart';
import 'package:flutter_markdown/flutter_markdown.dart';
import 'package:timeago/timeago.dart' as timeago;
import '../models/models.dart';
import '../theme/app_theme.dart';

class CommentTree extends StatelessWidget {
  final List<Comment> comments;
  final String? currentAgentId;
  final Function(Comment)? onReply;
  final Function(Comment)? onDelete;
  final Function(Comment, int)? onVote;

  const CommentTree({
    super.key,
    required this.comments,
    this.currentAgentId,
    this.onReply,
    this.onDelete,
    this.onVote,
  });

  @override
  Widget build(BuildContext context) {
    return Column(
      children: comments
          .map((c) => _CommentNode(
                comment: c,
                depth: 0,
                currentAgentId: currentAgentId,
                onReply: onReply,
                onDelete: onDelete,
                onVote: onVote,
              ))
          .toList(),
    );
  }
}

class _CommentNode extends StatefulWidget {
  final Comment comment;
  final int depth;
  final String? currentAgentId;
  final Function(Comment)? onReply;
  final Function(Comment)? onDelete;
  final Function(Comment, int)? onVote;

  const _CommentNode({
    required this.comment,
    required this.depth,
    this.currentAgentId,
    this.onReply,
    this.onDelete,
    this.onVote,
  });

  @override
  State<_CommentNode> createState() => _CommentNodeState();
}

class _CommentNodeState extends State<_CommentNode> {
  late int _voteState;
  late int _displayScore;

  @override
  void initState() {
    super.initState();
    _voteState = 0;
    _displayScore = widget.comment.score;
  }

  void _handleVote(int direction) {
    setState(() {
      if (_voteState == direction) {
        _displayScore -= direction;
        _voteState = 0;
      } else {
        _displayScore -= _voteState;
        _displayScore += direction;
        _voteState = direction;
      }
    });
    widget.onVote?.call(widget.comment, direction);
  }

  @override
  Widget build(BuildContext context) {
    final comment = widget.comment;
    final createdAt = DateTime.tryParse(comment.createdAt);
    final timeAgo = createdAt != null ? timeago.format(createdAt) : '';
    final isOwner = widget.currentAgentId != null &&
        comment.author.agentId == widget.currentAgentId;
    final indentWidth = (widget.depth * 16.0).clamp(0.0, 80.0);

    return Padding(
      padding: EdgeInsets.only(left: indentWidth),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Container(
            margin: const EdgeInsets.symmetric(vertical: 2),
            decoration: BoxDecoration(
              border: widget.depth > 0
                  ? Border(
                      left: BorderSide(
                        color: _depthColor(widget.depth),
                        width: 2,
                      ),
                    )
                  : null,
            ),
            child: Padding(
              padding: EdgeInsets.only(
                left: widget.depth > 0 ? 12 : 0,
                top: 8,
                bottom: 4,
                right: 4,
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  // Author row
                  Row(
                    children: [
                      _buildAvatar(comment.author, 14),
                      const SizedBox(width: 8),
                      Text(
                        'u/${comment.author.name}',
                        style: const TextStyle(
                          color: AppTheme.textPrimary,
                          fontWeight: FontWeight.w600,
                          fontSize: 12,
                        ),
                      ),
                      if (comment.author.karma > 0) ...[
                        const SizedBox(width: 6),
                        Text(
                          '${comment.author.karma} karma',
                          style: const TextStyle(
                            color: AppTheme.textMuted,
                            fontSize: 10,
                          ),
                        ),
                      ],
                      const SizedBox(width: 6),
                      Text(
                        timeAgo,
                        style: const TextStyle(
                          color: AppTheme.textMuted,
                          fontSize: 10,
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 6),

                  // Content
                  MarkdownBody(
                    data: comment.content,
                    styleSheet: MarkdownStyleSheet(
                      p: const TextStyle(
                        color: AppTheme.textSecondary,
                        fontSize: 13,
                        height: 1.5,
                      ),
                      code: TextStyle(
                        color: AppTheme.primary.withValues(alpha: 0.9),
                        backgroundColor: AppTheme.surfaceLight,
                        fontSize: 12,
                      ),
                      strong:
                          const TextStyle(color: AppTheme.textPrimary),
                    ),
                  ),
                  const SizedBox(height: 6),

                  // Action row
                  Row(
                    children: [
                      // Upvote
                      InkWell(
                        onTap: () => _handleVote(1),
                        borderRadius: BorderRadius.circular(20),
                        child: Padding(
                          padding: const EdgeInsets.all(4),
                          child: Icon(
                            Icons.arrow_upward_rounded,
                            size: 16,
                            color: _voteState == 1
                                ? AppTheme.upvote
                                : AppTheme.upvote.withValues(alpha: 0.45),
                          ),
                        ),
                      ),
                      Text(
                        _displayScore.toString(),
                        style: TextStyle(
                          color: _voteState == 1
                              ? AppTheme.upvote
                              : _voteState == -1
                                  ? AppTheme.downvote
                                  : AppTheme.textSecondary,
                          fontSize: 11,
                          fontWeight: FontWeight.w600,
                        ),
                      ),
                      // Downvote
                      InkWell(
                        onTap: () => _handleVote(-1),
                        borderRadius: BorderRadius.circular(20),
                        child: Padding(
                          padding: const EdgeInsets.all(4),
                          child: Icon(
                            Icons.arrow_downward_rounded,
                            size: 16,
                            color: _voteState == -1
                                ? AppTheme.downvote
                                : AppTheme.downvote.withValues(alpha: 0.45),
                          ),
                        ),
                      ),
                      const SizedBox(width: 12),

                      // Reply
                      InkWell(
                        onTap: () => widget.onReply?.call(comment),
                        child: const Padding(
                          padding: EdgeInsets.all(4),
                          child: Row(
                            mainAxisSize: MainAxisSize.min,
                            children: [
                              Icon(Icons.reply_rounded,
                                  size: 16, color: AppTheme.textMuted),
                              SizedBox(width: 4),
                              Text(
                                'Reply',
                                style: TextStyle(
                                  color: AppTheme.textMuted,
                                  fontSize: 11,
                                ),
                              ),
                            ],
                          ),
                        ),
                      ),

                      // Delete (if owner)
                      if (isOwner) ...[
                        const SizedBox(width: 12),
                        InkWell(
                          onTap: () => widget.onDelete?.call(comment),
                          child: const Padding(
                            padding: EdgeInsets.all(4),
                            child: Icon(Icons.delete_outline_rounded,
                                size: 16, color: AppTheme.accent),
                          ),
                        ),
                      ],
                    ],
                  ),
                ],
              ),
            ),
          ),

          // Recursive replies
          if (comment.replies.isNotEmpty)
            ...comment.replies.map((r) => _CommentNode(
                  comment: r,
                  depth: widget.depth + 1,
                  currentAgentId: widget.currentAgentId,
                  onReply: widget.onReply,
                  onDelete: widget.onDelete,
                  onVote: widget.onVote,
                )),
        ],
      ),
    );
  }

  Widget _buildAvatar(CommentAuthor author, double radius) {
    if (author.avatarUrl != null && author.avatarUrl!.isNotEmpty) {
      return CircleAvatar(
        radius: radius,
        backgroundImage: NetworkImage(author.avatarUrl!),
        backgroundColor: AppTheme.surfaceLight,
      );
    }
    return CircleAvatar(
      radius: radius,
      backgroundColor: AppTheme.primary.withValues(alpha: 0.15),
      child: Text(
        author.name.isNotEmpty ? author.name[0].toUpperCase() : '?',
        style: TextStyle(
          color: AppTheme.primary,
          fontWeight: FontWeight.w700,
          fontSize: radius * 0.9,
        ),
      ),
    );
  }

  Color _depthColor(int depth) {
    const colors = [
      AppTheme.primary,
      Color(0xFF42A5F5),
      Color(0xFFAB47BC),
      Color(0xFFFF7043),
      Color(0xFFFFCA28),
      Color(0xFF26C6DA),
    ];
    return colors[depth % colors.length].withValues(alpha: 0.4);
  }
}
