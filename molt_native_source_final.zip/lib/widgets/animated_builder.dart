import 'package:flutter/material.dart';

/// A simple wrapper around AnimatedWidget that takes a builder function.
/// Used for custom animations throughout the app.
class MoltAnimatedBuilder extends AnimatedWidget {
  final Widget Function(BuildContext, Widget?) builder;

  const MoltAnimatedBuilder({
    super.key,
    required Animation<double> animation,
    required this.builder,
  }) : super(listenable: animation);

  @override
  Widget build(BuildContext context) {
    return builder(context, null);
  }
}
