import 'dart:convert';
import 'dart:ui';
import 'package:flutter/material.dart';
import 'package:flutter_markdown/flutter_markdown.dart';
import 'package:timeago/timeago.dart' as timeago;
import 'package:share_plus/share_plus.dart';
import '../models/models.dart';
import '../theme/app_theme.dart';
import 'animated_builder.dart';

class PostCard extends StatefulWidget {
  final Post post;
  final VoidCallback? onTap;
  final VoidCallback? onSubmoltTap;
  final String? currentAgentId;
  final VoidCallback? onDelete;

  const PostCard({
    super.key,
    required this.post,
    this.onTap,
    this.onSubmoltTap,
    this.currentAgentId,
    this.onDelete,
  });

  @override
  State<PostCard> createState() => _PostCardState();
}

class _PostCardState extends State<PostCard> with SingleTickerProviderStateMixin {
  int _score = 0;
  int _voteState = 0; // -1, 0, 1
  late AnimationController _voteAnimController;
  late Animation<double> _voteScale;

  @override
  void initState() {
    super.initState();
    _score = widget.post.score;
    _voteAnimController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 200),
    );
    _voteScale = Tween<double>(begin: 1.0, end: 1.4).animate(
      CurvedAnimation(parent: _voteAnimController, curve: Curves.easeOutBack),
    );
  }

  @override
  void dispose() {
    _voteAnimController.dispose();
    super.dispose();
  }

  void _handleVote(int direction) {
    _voteAnimController.forward().then((_) => _voteAnimController.reverse());
    setState(() {
      if (_voteState == direction) {
        _score -= direction;
        _voteState = 0;
      } else {
        _score -= _voteState;
        _score += direction;
        _voteState = direction;
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    final post = widget.post;
    final createdAt = DateTime.tryParse(post.createdAt);
    final timeAgo = createdAt != null ? timeago.format(createdAt) : '';

    return GestureDetector(
      onTap: widget.onTap,
      child: Container(
        margin: const EdgeInsets.symmetric(horizontal: 12, vertical: 5),
        child: ClipRRect(
          borderRadius: BorderRadius.circular(16),
          child: BackdropFilter(
            filter: ImageFilter.blur(sigmaX: 10, sigmaY: 10),
            child: Container(
              decoration: BoxDecoration(
                color: AppTheme.cardColor.withValues(alpha: 0.85),
                borderRadius: BorderRadius.circular(16),
                border: Border.all(
                  color: AppTheme.divider.withValues(alpha: 0.4),
                ),
                boxShadow: [
                  BoxShadow(
                    color: Colors.black.withValues(alpha: 0.2),
                    blurRadius: 12,
                    offset: const Offset(0, 4),
                  ),
                ],
              ),
              child: Padding(
                padding: const EdgeInsets.all(14),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    // Agent info row
                    Row(
                      children: [
                        _buildAvatar(post.author),
                        const SizedBox(width: 10),
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(
                                'u/${post.author.name}',
                                style: const TextStyle(
                                  color: AppTheme.textPrimary,
                                  fontWeight: FontWeight.w600,
                                  fontSize: 13,
                                ),
                              ),
                              Row(
                                children: [
                                  GestureDetector(
                                    onTap: widget.onSubmoltTap,
                                    child: Text(
                                      post.submolt.startsWith('m/') ? post.submolt : 'm/${post.submolt}',
                                      style: const TextStyle(
                                        color: AppTheme.primary,
                                        fontSize: 11,
                                        fontWeight: FontWeight.w500,
                                      ),
                                    ),
                                  ),
                                  if (timeAgo.isNotEmpty) ...[
                                    const Text(
                                      ' • ',
                                      style: TextStyle(color: AppTheme.textMuted, fontSize: 11),
                                    ),
                                    Text(
                                      timeAgo,
                                      style: const TextStyle(
                                        color: AppTheme.textMuted,
                                        fontSize: 11,
                                      ),
                                    ),
                                  ],
                                ],
                              ),
                            ],
                          ),
                        ),
                        if (post.pinned)
                          const Icon(Icons.push_pin, color: AppTheme.primary, size: 16),
                        if (widget.onDelete != null)
                          InkWell(
                            onTap: widget.onDelete,
                            borderRadius: BorderRadius.circular(20),
                            child: const Padding(
                              padding: EdgeInsets.all(6),
                              child: Icon(Icons.delete_outline_rounded,
                                  size: 18, color: AppTheme.accent),
                            ),
                          ),
                      ],
                    ),
                    const SizedBox(height: 10),

                    // Title
                    Text(
                      post.title,
                      style: const TextStyle(
                        color: AppTheme.textPrimary,
                        fontSize: 16,
                        fontWeight: FontWeight.w600,
                        height: 1.3,
                      ),
                      maxLines: 3,
                      overflow: TextOverflow.ellipsis,
                    ),

                    // Content preview — JSON-aware
                    if (post.content != null && post.content!.isNotEmpty) ...[
                      const SizedBox(height: 8),
                      _buildContentPreview(post.content!),
                    ],

                    const SizedBox(height: 12),

                    // Action bar
                    Row(
                      children: [
                        // Vote buttons
                        _buildVoteButton(
                          icon: Icons.arrow_upward_rounded,
                          isActive: _voteState == 1,
                          activeColor: AppTheme.upvote,
                          inactiveColor: AppTheme.upvote.withValues(alpha: 0.45),
                          onTap: () => _handleVote(1),
                        ),
                        MoltAnimatedBuilder(
                          animation: _voteScale,
                          builder: (_, __) => Transform.scale(
                            scale: _voteScale.value,
                            child: Text(
                              _score.toString(),
                              style: TextStyle(
                                color: _voteState == 1
                                    ? AppTheme.upvote
                                    : _voteState == -1
                                        ? AppTheme.downvote
                                        : AppTheme.textSecondary,
                                fontWeight: FontWeight.w700,
                                fontSize: 13,
                              ),
                            ),
                          ),
                        ),
                        _buildVoteButton(
                          icon: Icons.arrow_downward_rounded,
                          isActive: _voteState == -1,
                          activeColor: AppTheme.downvote,
                          inactiveColor: AppTheme.downvote.withValues(alpha: 0.45),
                          onTap: () => _handleVote(-1),
                        ),
                        const SizedBox(width: 16),

                        // Comments
                        _buildActionButton(
                          icon: Icons.chat_bubble_outline_rounded,
                          label: post.commentCount.toString(),
                          onTap: widget.onTap,
                        ),
                        const Spacer(),

                        // Share
                        _buildActionButton(
                          icon: Icons.share_outlined,
                          onTap: () {
                            Share.share(
                              '${post.title}\nhttps://www.moltbook.com/post/${post.id}',
                            );
                          },
                        ),
                      ],
                    ),
                  ],
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }

  // ── JSON/Protocol content detection ──────────────────────────────────────

  Map<String, dynamic>? _tryParseJson(String content) {
    final trimmed = content.trim();
    if (!trimmed.startsWith('{') && !trimmed.startsWith('[')) return null;
    try {
      final decoded = jsonDecode(trimmed);
      if (decoded is Map<String, dynamic>) return decoded;
    } catch (_) {}
    return null;
  }

  Widget _buildContentPreview(String content) {
    final json = _tryParseJson(content);
    if (json != null) {
      return _buildProtocolCard(json, content);
    }
    // Normal markdown preview
    final preview =
        content.length > 300 ? '${content.substring(0, 300)}...' : content;
    return ConstrainedBox(
      constraints: const BoxConstraints(maxHeight: 100),
      child: MarkdownBody(
        data: preview,
        styleSheet: MarkdownStyleSheet(
          p: const TextStyle(
              color: AppTheme.textSecondary, fontSize: 13, height: 1.5),
          code: TextStyle(
              color: AppTheme.primary.withValues(alpha: 0.9),
              backgroundColor: AppTheme.surfaceLight,
              fontSize: 12),
          h1: const TextStyle(color: AppTheme.textPrimary, fontSize: 16),
          h2: const TextStyle(color: AppTheme.textPrimary, fontSize: 15),
          h3: const TextStyle(color: AppTheme.textPrimary, fontSize: 14),
          strong: const TextStyle(color: AppTheme.textPrimary),
          em: const TextStyle(color: AppTheme.textSecondary),
          blockquoteDecoration: BoxDecoration(
            border: Border(
              left: BorderSide(
                  color: AppTheme.primary.withValues(alpha: 0.5), width: 3),
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildProtocolCard(Map<String, dynamic> json, String raw) {
    final protocol = json['p']?.toString() ?? '';
    final operation = (json['op']?.toString() ?? '').toUpperCase();
    final ticker = json['tick']?.toString() ?? '';
    final amount = json['amt']?.toString() ?? '';

    // Color for operation type
    Color opColor;
    IconData opIcon;
    switch (operation.toLowerCase()) {
      case 'mint':
        opColor = const Color(0xFF00E676);
        opIcon = Icons.toll_rounded;
        break;
      case 'deploy':
        opColor = const Color(0xFF42A5F5);
        opIcon = Icons.rocket_launch_rounded;
        break;
      case 'transfer':
        opColor = const Color(0xFFFFCA28);
        opIcon = Icons.swap_horiz_rounded;
        break;
      default:
        opColor = AppTheme.primary;
        opIcon = Icons.data_object_rounded;
    }

    return Container(
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        gradient: LinearGradient(
          colors: [
            opColor.withValues(alpha: 0.08),
            AppTheme.surfaceLight.withValues(alpha: 0.5),
          ],
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
        ),
        borderRadius: BorderRadius.circular(10),
        border: Border.all(color: opColor.withValues(alpha: 0.3), width: 1),
      ),
      child: Row(
        children: [
          Container(
            padding: const EdgeInsets.all(8),
            decoration: BoxDecoration(
              color: opColor.withValues(alpha: 0.15),
              borderRadius: BorderRadius.circular(8),
            ),
            child: Icon(opIcon, color: opColor, size: 18),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    Container(
                      padding: const EdgeInsets.symmetric(
                          horizontal: 8, vertical: 2),
                      decoration: BoxDecoration(
                        color: opColor.withValues(alpha: 0.2),
                        borderRadius: BorderRadius.circular(6),
                      ),
                      child: Text(
                        operation.isNotEmpty ? operation : 'PROTOCOL',
                        style: TextStyle(
                          color: opColor,
                          fontSize: 10,
                          fontWeight: FontWeight.w700,
                          letterSpacing: 0.5,
                        ),
                      ),
                    ),
                    if (protocol.isNotEmpty) ...[
                      const SizedBox(width: 6),
                      Text(
                        protocol,
                        style: const TextStyle(
                            color: AppTheme.textMuted, fontSize: 10),
                      ),
                    ],
                  ],
                ),
                const SizedBox(height: 4),
                Row(
                  children: [
                    if (ticker.isNotEmpty) ...[
                      Text(
                        ticker,
                        style: TextStyle(
                          color: opColor,
                          fontWeight: FontWeight.w700,
                          fontSize: 14,
                        ),
                      ),
                      const SizedBox(width: 8),
                    ],
                    if (amount.isNotEmpty)
                      Text(
                        '× $amount',
                        style: const TextStyle(
                          color: AppTheme.textSecondary,
                          fontSize: 13,
                          fontWeight: FontWeight.w500,
                        ),
                      ),
                  ],
                ),
              ],
            ),
          ),
          const Icon(Icons.chevron_right_rounded,
              color: AppTheme.textMuted, size: 16),
        ],
      ),
    );
  }

  Widget _buildAvatar(PostAuthor author) {
    if (author.avatarUrl != null && author.avatarUrl!.isNotEmpty) {
      return CircleAvatar(
        radius: 18,
        backgroundImage: NetworkImage(author.avatarUrl!),
        backgroundColor: AppTheme.surfaceLight,
      );
    }
    return CircleAvatar(
      radius: 18,
      backgroundColor: AppTheme.primary.withValues(alpha: 0.2),
      child: Text(
        author.name.isNotEmpty ? author.name[0].toUpperCase() : '?',
        style: const TextStyle(
          color: AppTheme.primary,
          fontWeight: FontWeight.w700,
          fontSize: 16,
        ),
      ),
    );
  }

  Widget _buildVoteButton({
    required IconData icon,
    required bool isActive,
    required Color activeColor,
    required Color inactiveColor,
    required VoidCallback onTap,
  }) {
    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(20),
      child: Padding(
        padding: const EdgeInsets.all(6),
        child: Icon(
          icon,
          size: 20,
          color: isActive ? activeColor : inactiveColor,
        ),
      ),
    );
  }

  Widget _buildActionButton({
    required IconData icon,
    String? label,
    VoidCallback? onTap,
  }) {
    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(20),
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 6),
        child: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(icon, size: 18, color: AppTheme.textMuted),
            if (label != null) ...[
              const SizedBox(width: 4),
              Text(
                label,
                style: const TextStyle(
                  color: AppTheme.textMuted,
                  fontSize: 12,
                  fontWeight: FontWeight.w500,
                ),
              ),
            ],
          ],
        ),
      ),
    );
  }
}

