package com.moltbook.molt_native

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
